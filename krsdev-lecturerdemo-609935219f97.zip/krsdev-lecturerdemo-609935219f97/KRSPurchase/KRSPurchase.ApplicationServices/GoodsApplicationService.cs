﻿using KRSPurchase.Domain;

namespace KRSPurchase.ApplicationServices
{
  public class GoodsApplicationService
  {
    private readonly GoodValidator _validator = new ();

    private IList<Good> _goods = new List<Good> ()
    {
      new Good("KYBRD", "Keyboard"),
      new Good("PRJTR", "Projecter"),
      new Good("CHAIR", "Chair"),
    };

    public async Task<bool> AddAsync(Good good)
    {
      var validationResult = _validator.Validate(good);
      if (!validationResult.IsValid) return false;

      _goods.Add(good);

      return true;
    }

    public async Task<bool> DeleteAsync(string code)
    {
      var good = await FindByCodeAsync(code);
      if (good == null) return false;
      
      _goods.Remove(good);
      return true;
    }

    public async Task<bool> EditAsync(Good existingGood)
    {
      var good = await FindByCodeAsync(existingGood.Code);
      var validationResult = _validator.Validate(good);
      if (good == null || !validationResult.IsValid) return false;

      _goods.Select(g => g.Code == existingGood.Code ? existingGood : g);
      return true;
    }

    public async Task<Good> FindByCodeAsync(string code)
    {
      return _goods.FirstOrDefault(g => g.Code == code)!;
    }

    public async Task<IList<Good>> ListAsync()
    {
      return _goods;
    }
  }
}
