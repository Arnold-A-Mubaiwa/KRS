using KRSPurchase.ApplicationServices;
using KRSPurchase.Domain;

namespace KRSPurchase.Tests
{
  public class ManageGoods
  {

    private readonly GoodValidator _validator = new ();
    private readonly GoodsApplicationService _service = new ();

    [Fact]
    public void ShouldCreateANewGood()
    {
      //given a code "CC001" and name "Coke"
      const string code = "CC001";
      const string name = "Coke";
      //when I create a good
      var good = new Good(code, name);
      //then a good should exist with code "CC001" and name "Coke"
      Assert.NotNull(good);
      Assert.Equal(code, good.Code);
      Assert.Equal(name, good.Name);
    }

    [Fact]
    public void ShouldValidateAValidGood()
    {
      //given a good with code "PAPER" and name "Paper"
      var good = new Good("PAPER","Paper");
      //when we validate the good 
      var validationResult = _validator.Validate(good);
      //then the good should be valid
      Assert.True(validationResult.IsValid);
    }

    [Fact]
    public void ShouldFailToValidateInvalidGood()
    {
      //given
      var good = new Good("PPR", string.Empty);
      //when
      var validationResult = _validator.Validate(good);
      //then 
      Assert.False(validationResult.IsValid);
    }

    [Fact]
    public async Task ShouldAddAGoodToApplicationService()
    {
      //given a good with code "MOUSE" and name "Mouse"
      var good = new Good("MOUSE", "mouse");
      //when we add a good to the application service
      var goodAdded = await _service.AddAsync(good);
      //then the good should be added succesfully
      Assert.True(goodAdded);
      var addedGood = await _service.FindByCodeAsync(good.Code);
      Assert.NotNull(addedGood);
      Assert.Equal(good.Code, addedGood.Code);
    }

    [Fact]
    public async Task ShouldFindGoodByCode()
    {
      //given a code "KYBRD"
      //and an goods application service containing a good with that code
      const string code = "KYBRD";
      //when we find the good
      var good = await _service.FindByCodeAsync(code);
      //then the good should exist with that code
      Assert.NotNull(good);
      Assert.Equal(code, good.Code);
    }

    [Fact]
    public async Task ShouldDeleteGoodByCode()
    {
      //given a code "APPLE" 
      //and an goods application service containing a good with that code
      const string code = "APPLE";
      const string name = "Apple";
      var goodAdded = await _service.AddAsync(new Good(code, name));
      Assert.True(goodAdded);

      //when we delete that good
      var goodDeleted = await _service.DeleteAsync(code);

      //then should no longer exist
      Assert.True(goodDeleted);
      var deletedGood = await _service.FindByCodeAsync(code);
      Assert.Null(deletedGood);
    }

    [Fact]
    public async Task ShouldEditAnExistingGood()
    {
      //given an existing good with code "PRJTR" and name "Projecter"
      const string code = "PRJTR";
      const string name = "Projector";
      var existingGood = await _service.FindByCodeAsync(code);

      //when we edit the good
      //set the name to "Projector"
      existingGood.Name = name;
      var goodEdited = await _service.EditAsync(existingGood);

      //then the name should be "Projector"
      var editedGood = await _service.FindByCodeAsync(code);
      Assert.True(goodEdited);
      Assert.Equal(name, editedGood.Name);
    }

    [Fact]
    public async Task ShouldGetAListofGoods()
    {
      //given an application service containing good with code "CHAIR" 
      //when we get the list of goods
      var goods = await _service.ListAsync();
      
      //then we should have a list with the existing goods
      Assert.Contains(goods, g => g.Code == "CHAIR");
      Assert.True(goods.Count() > 1);
    }
  }
}