## Domain Overview

### Overview

### KRS Purchase

Develop an application to handle KRS' purchases.

KRS purchases stationery (3-ring binders, printer and fax paper, board markers etc.),  
groceries (coffee, milk, sugar, beer, pies etc...) and computer equipment (cabling, fly leads etc.)  
from various suppliers.  Each supplier has different names for the goods.  
The prices of the goods differ from supplier to supplier. The lead time for each supplier differs.

KRS would like to place orders for the goods - they would like to specify the required delivery date of the goods.  
A facility must be provided to cancel purchase orders that are overdue.

### Sprint 1 Stories

#### Maintain Goods
As Sue  
I want to add, edit and delete goods  
So that I have an accurate list of goods available

#### Maintain Suppliers
As Sue  
I want to add, edit and delete suppliers  
So that I have an accurate list of suppliers

#### Link Goods to Supplier
As Sue  
I want to link goods to a supplier  
So that I can see an accurate list of goods available from each supplier

#### Manage Purchase Orders
As Sue  
I want to capture a purchase order  
So that I track the items ordered from each supplier