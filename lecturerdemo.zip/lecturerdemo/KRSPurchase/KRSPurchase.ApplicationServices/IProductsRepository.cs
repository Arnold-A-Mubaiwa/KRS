using KRSPurchase.Domain;

namespace KRSPurchase.ApplicationServices;

public interface IProductsRepository
{
  public Task<IList<Product>> ListAsync();
  public Task<Product> FindByCodeAsync(string code);
  public Task<string> AddAsync(Product product);
  public Task<bool> EditAsync(Product product);
  public Task<bool> DeleteAsync(string code);
}