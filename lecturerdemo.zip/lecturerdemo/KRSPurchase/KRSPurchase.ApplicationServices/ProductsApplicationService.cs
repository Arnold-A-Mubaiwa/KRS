﻿using FluentResults;
using FluentValidation.Results;
using KRSPurchase.Domain;

namespace KRSPurchase.ApplicationServices
{
  public class ProductsApplicationService
  {
    private readonly ProductValidator _validator = new ();
    private readonly IProductsRepository _repository;
    
    public ProductsApplicationService(IProductsRepository repository)
    {
      _repository = repository;
    }

    public async Task<Result<string>> AddAsync(Product product)
    {
      var validationResult = _validator.Validate(product);
      if (!validationResult.IsValid)
        return Result
          .Fail<string>(validationResult.Errors.Select(e => e.ErrorMessage));

      var addedCode = await _repository.AddAsync(product);
      return Result.Ok(addedCode);
    }

    public async Task<Result<bool>> DeleteAsync(string code)
    {
      var existingProduct = (await FindByCodeAsync(code)).Value;
      
      if(existingProduct == null)
        return Result.Fail<bool>("Product not found");
      
      return await _repository.DeleteAsync(code);
    }

    public async Task<Result<bool>> EditAsync(Product product)
    {
      var existingProduct = (await FindByCodeAsync(product.Code)).Value;
      
      if(existingProduct == null)
        return Result.Fail<bool>("Product not found");
      
      var validationResult = await _validator.ValidateAsync(product);
      
      if (!validationResult.IsValid) 
        return Result.Fail<bool>(validationResult.Errors.Select(vr => vr.ErrorMessage));

      var editResult = await _repository.EditAsync(product);
      return Result.Ok(editResult);
    }

    public async Task<Result<Product>> FindByCodeAsync(string code)
    {
      var product = await _repository.FindByCodeAsync(code);
      return Result.Ok(product);
    }

    public async Task<Result<IList<Product>>> ListAsync()
    {
      var products = await _repository.ListAsync();
      return Result.Ok(products);
    }
  }
}
