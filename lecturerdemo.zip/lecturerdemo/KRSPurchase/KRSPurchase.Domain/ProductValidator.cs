﻿using FluentValidation;

namespace KRSPurchase.Domain;

public class ProductValidator: AbstractValidator<Product>
{

	public ProductValidator()
	{
		RuleFor(g => g.Code).NotEmpty().MinimumLength(5).MaximumLength(5);
		RuleFor(g => g.Name).NotEmpty();
	}

}

