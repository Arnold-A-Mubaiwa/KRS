using KRSPurchase.ApplicationServices;
using KRSPurchase.Domain;
using KRSPurchase.Tests.Mocks;

namespace KRSPurchase.Tests
{
  public class ManageProducts
  {

    private readonly ProductValidator _validator = new ();
    private readonly ProductsApplicationService _service = new (new MockProductsRepository());

    [Fact]
    public void ShouldCreateANewProduct()
    {
      //given a code "CC001" and name "Coke"
      const string code = "CC001";
      const string name = "Coke";
      //when I create a product
      var product = new Product(code, name);
      //then a product should exist with code "CC001" and name "Coke"
      Assert.NotNull(product);
      Assert.Equal(code, product.Code);
      Assert.Equal(name, product.Name);
    }

    [Fact]
    public void ShouldValidateAValidProduct()
    {
      //given a product with code "PAPER" and name "Paper"
      var product = new Product("PAPER","Paper");
      //when we validate the product 
      var validationResult = _validator.Validate(product);
      //then the product should be valid
      Assert.True(validationResult.IsValid);
    }

    [Fact]
    public void ShouldFailToValidateInvalidProduct()
    {
      //given
      var product = new Product("PPR", string.Empty);
      //when
      var validationResult = _validator.Validate(product);
      //then 
      Assert.False(validationResult.IsValid);
    }

    [Fact]
    public async Task ShouldAddAProductToApplicationService()
    {
      //given a product with code "MOUSE" and name "Mouse"
      var product = new Product("MOUSE", "mouse");
      //when we add a product to the application service
      var (isSuccess, isFailed,productCode,errors) = await _service.AddAsync(product);
      //then the product should be added succesfully
      Assert.True(isSuccess);
      Assert.False(isFailed);
      Assert.Null(errors);
      var addedProduct = (await _service.FindByCodeAsync(productCode)).Value;
      Assert.NotNull(addedProduct);
      Assert.Equal(product.Code, addedProduct.Code);
    }

    [Fact]
    public async Task ShouldFindProductByCode()
    {
      //given a code "KYBRD"
      //and an products application service containing a product with that code
      const string code = "KYBRD";
      //when we find the product
      var (isSuccess, isFailed, product, errors) = await _service.FindByCodeAsync(code);
      //then the product should exist with that code
      Assert.NotNull(product);
      Assert.True(isSuccess);
      Assert.False(isFailed);
      Assert.Null(errors);
      Assert.Equal(code, product.Code);
    }

    [Fact]
    public async Task ShouldDeleteProductByCode()
    {
      //given a code "APPLE" 
      //and an products application service containing a product with that code
      const string code = "APPLE";
      const string name = "Apple";
      var addedCode = (await _service.AddAsync(new Product(code, name))).Value;
      Assert.Equal(code,addedCode);

      //when we delete that product
      var (isSuccess, isFailed,productDeleted, errors) = await _service.DeleteAsync(code);

      //then should no longer exist
      Assert.True(isSuccess);
      Assert.False(isFailed);
      Assert.Null(errors);
      Assert.True(productDeleted);
      var deletedProduct = (await _service.FindByCodeAsync(code)).Value;
      Assert.Null(deletedProduct);
    }

    [Fact]
    public async Task ShouldEditAnExistingProduct()
    {
      //given an existing product with code "PRJTR" and name "Projecter"
      const string code = "PRJTR";
      const string name = "Projector";
      var existingProduct = (await _service.FindByCodeAsync(code)).Value;

      //when we edit the product
      //set the name to "Projector"
      existingProduct.Name = name;
      var (isSuccess, isFailed,productEdited, errors) = await _service.EditAsync(existingProduct);

      //then the name should be "Projector"
      var editedProduct = (await _service.FindByCodeAsync(code)).Value;
      Assert.True(isSuccess);
      Assert.False(isFailed);
      Assert.Null(errors);
      Assert.True(productEdited);
      Assert.Equal(name, editedProduct.Name);
    }

    [Fact]
    public async Task ShouldGetAListOfProducts()
    {
      //given an application service containing product with code "CHAIR" 
      //when we get the list of products
      var listResult = await _service.ListAsync();
      
      //then we should have a list with the existing products
      Assert.Contains(listResult.Value, p => p.Code == "CHAIR");
      Assert.True(listResult.IsSuccess);
      Assert.True(listResult.Value.Count > 1);
    }
  }
}