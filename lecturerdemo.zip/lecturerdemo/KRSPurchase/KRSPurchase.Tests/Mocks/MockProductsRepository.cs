using KRSPurchase.ApplicationServices;
using KRSPurchase.Domain;

namespace KRSPurchase.Tests.Mocks;

public class MockProductsRepository : IProductsRepository
{
  private IList<Product> _products = new List<Product> ()
  {
    new Product("KYBRD", "Keyboard"),
    new Product("PRJTR", "Projecter"),
    new Product("CHAIR", "Chair"),
  };
  
  public async Task<IList<Product>> ListAsync()
  {
    return _products;
  }

  public async Task<Product> FindByCodeAsync(string code)
  {
    return _products.FirstOrDefault(g => g.Code == code)!;
  }

  public async Task<string> AddAsync(Product product)
  {
    _products.Add(product);
    return product.Code;
  }

  public async Task<bool> EditAsync(Product product)
  {
    _products = _products
      .Select(g => g.Code == product.Code ? product : g)
      .ToList();
      
    return true;
  }

  public async Task<bool> DeleteAsync(string code)
  {
    var product = await FindByCodeAsync(code);
    if (product == null) return false;
      
    _products.Remove(product);
    return true;
  }
}