using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KRSPurchase.ApplicationServices;
using KRSPurchase.Domain;
using KRSPurchase.WebApi.Extensions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace KRSPurchase.WebApi.Controllers
{
  [Route("api/[controller]")]
  [ApiController]
  public class ProductsController : ControllerBase
  {
    private readonly ProductsApplicationService _service;

    public ProductsController(ProductsApplicationService service)
    {
      _service = service;
    }

    // GET: api/Products
    [HttpGet]
    public async Task<IActionResult> Get()
      => (await _service.ListAsync()).ToActionResult(Request.HttpContext);

    // GET: api/Products/CODE1
    [HttpGet("{code}", Name = "Get")]
    public async Task<IActionResult> Get(string code)
      => (await _service.FindByCodeAsync(code)).ToActionResult(Request.HttpContext);

    // POST: api/Products
    [HttpPost]
    public async Task<IActionResult> Post([FromBody] Product product)
      => (await _service.AddAsync(product)).ToActionResult(Request.HttpContext);

    // PUT: api/Products/5
    [HttpPut("{code}")]
    public async Task<IActionResult> Put(string code, [FromBody] Product product)
      => (await _service.EditAsync(product)).ToActionResult(Request.HttpContext);

    // DELETE: api/Products/5
    [HttpDelete("{code}")]
    public async Task<IActionResult> Delete(string code)
      => (await _service.DeleteAsync(code)).ToActionResult(Request.HttpContext);
    
  }
}