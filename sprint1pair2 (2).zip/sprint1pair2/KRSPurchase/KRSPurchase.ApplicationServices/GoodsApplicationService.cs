﻿using KRSPurchase.Domain;

namespace KRSPurchase.ApplicationServices
{
  public class GoodsApplicationService
  {
    private readonly GoodValidator _validator = new ();
    private static List<Good> goods = new List<Good>()
    {
      new Good("KYBRD", "Keyboard"),
      new Good("PRJTR", "Projecter"),
      new Good("CHAIR", "Chair"),
      new Good("F2431", "Laptop"),
    };

  public async Task<bool> AddAsync(Good good)
    {
      
      var validate = _validator.Validate(good);
      if(!validate.IsValid)
        return false;
      goods.Add(good);
      return true;
    }

    public async Task<Good> FindAsync(string code)
    {
      return goods.FirstOrDefault(g => g.Code == code)!;
    }

    public async Task<bool> DeleteAsync(string code)
    {
      var good = await FindAsync(code);
      if (good == null)return false;
      
      goods.Remove(good);
      return true;
      
      
    }
    public async Task<bool> EditAsync(Good existingGood)
    {
      var good = await FindAsync(existingGood.Code);
      // good.Name = existingGood.Name;

      var checkValidity = _validator.Validate(good);
      if (!(checkValidity.IsValid && good != null)) return false;
      // updating goods list
      goods = goods.Select(g => g.Code == existingGood.Code ? existingGood : g).ToList();
      return true;
    }
  }
}