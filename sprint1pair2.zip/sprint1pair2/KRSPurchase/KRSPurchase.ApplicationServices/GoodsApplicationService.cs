﻿using KRSPurchase.Domain;

namespace KRSPurchase.ApplicationServices
{
  public class GoodsApplicationService
  {
    private readonly GoodValidator _validator = new ();
    private static List<Good> _goods = new List<Good>()
    {
      new Good("KYBRD", "Keyboard"),
      new Good("PRJTR", "Projecter"),
      new Good("CHAIR", "Chair"),
      new Good("F2431", "Laptop"),
    };

  public async Task<bool> AddAsync(Good good)
    {
      
      var validate = _validator.Validate(good);
      var checkDupl = await CheckDuplicate(good.Code);
      if(!validate.IsValid ||  checkDupl)
        return false;
      _goods.Add(good);
      return true;
    }

    public async Task<Good> FindAsync(string code)
    {
      return _goods.FirstOrDefault(g => g.Code == code)!;
    }

    public async Task<bool> DeleteAsync(string code)
    {
      var good = await FindAsync(code);
      if (good == null)return false;
      
      _goods.Remove(good);
      return true;
      
      
    }
    public async Task<bool> EditAsync(Good existingGood)
    {
      var good = await FindAsync(existingGood.Code);
      // good.Name = existingGood.Name;

      var checkValidity = _validator.Validate(good);
      if (!checkValidity.IsValid || good == null) return false;
      // updating goods list
      _goods = _goods.Select(g => g.Code == existingGood.Code ? existingGood : g).ToList();
      return true;
    }

    public async Task<List<Good>> ListGoods() 
    {
      return _goods;
    }

    public async Task<bool> CheckDuplicate(string code)
    {
      var good = await FindAsync(code);
      return (good != null);
    }
   
  }
}