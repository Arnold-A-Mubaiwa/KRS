﻿using KRSPurchase.Domain;

namespace KRSPurchase.ApplicationServices
{
  public class GoodsApplicationService
  {
    private static List<Good> goods = new List<Good>();
    public static bool AddAsync(Good good)
    {
      goods.Add(good);
      return (goods.Contains(good))?true:false;
    }

    public static Good FindAsync(string code)
    {
      return new Good("SAMPL", "SAMPLE");
    }
  }
}