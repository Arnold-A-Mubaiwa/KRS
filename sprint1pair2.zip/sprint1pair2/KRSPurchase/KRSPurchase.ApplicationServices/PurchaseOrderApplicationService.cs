﻿using KRSPurchase.Domain;


namespace KRSPurchase.ApplicationServices
{
  public class PurchaseOrderApplicationService
  {
    private List<PurchaseOrder> _purchaseOrders = new List<PurchaseOrder>()
    {
          new PurchaseOrder ( new Supplier("ABCDA", "Ab", 3), new List<Item>() { new Item(new Good("WEARV", "Wearing Clothe"), 2, 50.52m) }),
    };

    public async Task<PurchaseOrder> FindPurchaseOrderAsync(int number)
    {
      return _purchaseOrders.FirstOrDefault(p => p.Number == number)!;
    }

    public async Task<bool> AddPurchaseOrderAsync(PurchaseOrder purchase)
    {
      purchase.Number = _purchaseOrders.Count() + 1;
      _purchaseOrders.Add(purchase);
      return true;
    }

    public async Task<bool> AddToExistingAsync(PurchaseOrder purchase, List<Item> items)
    {

      items.ForEach(purchase.Add);
      return true;
    }

    public async Task<bool> CancelOrderAsync(int number)
    {
      var findPurchase = await FindPurchaseOrderAsync (number);

      if (findPurchase == null) return false;

      /*_purchaseOrders.Remove(findPurchase);*/
      findPurchase.Active= false;
      return true;
    }

    public async Task<List<PurchaseOrder>> GetPurchaseList()
    {
      return _purchaseOrders;
    }


  }
}
