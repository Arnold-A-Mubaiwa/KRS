﻿using FluentValidation;
namespace KRSPurchase.Domain
{
  public class ItemValidator: AbstractValidator<Item>
  {
    public ItemValidator() {
      RuleFor(i => i.Good).SetValidator(new GoodValidator());
      RuleFor(i => i.Quantity).NotEmpty().GreaterThan(0);
      RuleFor(i => i.Price).NotEmpty().GreaterThan(0);
    }
  }
}
