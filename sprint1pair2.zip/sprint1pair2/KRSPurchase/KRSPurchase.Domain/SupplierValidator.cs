﻿using FluentValidation;

namespace KRSPurchase.Domain
{
  public class SupplierValidator : AbstractValidator<Supplier>
  {
    public SupplierValidator() {
      RuleFor(s => s.Code).NotEmpty().MaximumLength(5).MinimumLength(5);
      RuleFor(s => s.Name).NotEmpty();
      RuleFor(s => s.LeadTime).GreaterThan(0);
    }
  }
}
