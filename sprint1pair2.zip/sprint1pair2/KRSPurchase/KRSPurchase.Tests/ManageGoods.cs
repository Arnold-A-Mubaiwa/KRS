using KRSPurchase.ApplicationServices;
using KRSPurchase.Domain;
namespace KRSPurchase.Tests
{
  public class ManageGoods
  {
    [Fact]
    public void ShouldCreateGood()
    {
      //Given good name = "DELL" and code = "VPROM" 
      var name = "DELL";
      var code = "VPROM";
      //When create good 
      var good = new Good(code, name);
      //Then good should exist
      Assert.NotNull(good);
      Assert.Equal(name, good.Name);
      Assert.True(good.Code == code);
      
    }
    [Fact]
    public void ShouldAddGood()
    {
      //Give Good name="BOTTLE" code="BOT22"
      var good = new Good("BOT22", "BOTTLE");
      //When  Good is Added to the application Service
      var addedGood = GoodsApplicationService.AddAsync(good);
      Assert.True(addedGood);
    }
    [Fact]
    public async Task ShouldFindGoodByCode()
    {
      //Given Good by code = "F2431"
      var code = "F2431";
      //WHEN we find code
      var good = await GoodsApplicationService.FindAsync(code);
      //Then the good exists
      Assert.Equal(code, good.Code);
    }
  }
}