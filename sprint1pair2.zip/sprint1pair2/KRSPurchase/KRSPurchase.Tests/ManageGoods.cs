using KRSPurchase.ApplicationServices;
using KRSPurchase.Domain;

namespace KRSPurchase.Tests
{
  public class ManageGoods
  {
    private readonly GoodsApplicationService _service = new();
    private readonly GoodValidator _validator = new();

    [Fact]
    public void ShouldCreateGood()
    {
      //Given good name = "DELL" and code = "VPROM" 
      var name = "DELL";
      var code = "VPROM";
      //When create good 
      var good = new Good(code, name);
      //Then good should exist
      Assert.NotNull(good);
      Assert.Equal(name, good.Name);
      Assert.Equal(good.Code, code);
      
    }

    [Fact]
    public async Task ShouldAddGood()
    {
      //Give Good name="BOTTLE" code="BOT22"
      var good = new Good("BOT22", "BOTTLE");
      //When  Good is Added to the application Service
      var addedGood = await _service.AddAsync(good);
      Assert.True(addedGood);
      var foundGood = await _service.FindAsync("BOT22");
      //Then the good exists
      Assert.Equal("BOT22", foundGood.Code);
    }

    [Fact]
    public async Task ShouldFindGoodByCode()
    {
      //Given Good by code = "CHAIR"
      var code = "CHAIR";
      //WHEN we find code
      var good = await _service.FindAsync(code);
      //Then the good exists
      Assert.Equal(code, good.Code);
    }

    [Fact]
    public void ShouldValidateValidGood()
    {
      // Given good name="MARKER" and code = "PMERK"
      var good = new Good("PMERK", "MARKER");
      // When we validate the good 
      var validate = _validator.Validate(good);
      //Then the good is valid
      Assert.True(validate.IsValid);
    }

    [Fact]
    public void ShouldValidateInvalideGood()
    {
      // Given invalid good with code = "PMEK" and name = ""
      var good = new Good("PMEK", "");
      // When we validate the good 
      var validate = _validator.Validate(good);
      //Then the good is inValid
      Assert.False(validate.IsValid);
    }

    [Fact]
    public async Task ShouldDeleteGood()
    {
      // Given good code = "F2431"
      var code = "F2431";
      // When deleting the good
      var goodDeleted = await _service.DeleteAsync(code);
      // Then the good should be deleted
      Assert.True(goodDeleted);
      var findGood = await _service.FindAsync(code);
      Assert.Null(findGood);
    }

    [Fact]
    public async Task ShouldEditGood()
    {
      // Given the code = "PRJTR", name = "Projecter"
      var code = "PRJTR";
      var name = "Projectors";
      var existingGood = await _service.FindAsync(code);
      // When editing the good
      existingGood.Name = name;
      var newGood = await _service.EditAsync(existingGood);
      var edittedGood = await _service.FindAsync(code);
      //Then the good should be edited
      Assert.True(newGood);
      Assert.Equal(name, edittedGood.Name);
    }

    [Fact]
    public async Task ShouldListGood()
    {
      // Given the list of Good
      // When listing the goods
      var listGoods = await _service.ListGoods();// we want the list of goods
      // Then should return all goods
      Assert.Contains(listGoods, g => g.Code == "KYBRD");
      Assert.True(listGoods.Count > 1);
    }
    [Fact]
    public async Task ShouldCheckDuplicate()
    {
      // Given the good by code
      var code = "PRJTR";
      // When the good has duplicate
      var goodExist = await _service.CheckDuplicate(code);
      // Then the duplicate should exist
      Assert.True(goodExist);
    }
    [Fact]
    public async Task ShouldFailAdd()
    {
      // Given the good
      var good = new Good("PRJTR", "BOTTLE2");
      // When the good has duplicate
      var goodExist = await _service.AddAsync(good);
      // Then the good shouldn't be added
      Assert.False(goodExist);

    }
  }
}