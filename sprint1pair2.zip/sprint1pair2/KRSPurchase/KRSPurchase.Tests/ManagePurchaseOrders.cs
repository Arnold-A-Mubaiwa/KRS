﻿using KRSPurchase.ApplicationServices;
using KRSPurchase.Domain;

namespace KRSPurchase.Tests
{
  public class ManagePurchaseOrders
  {
    private readonly PurchaseOrderValidator _validator = new();
    private readonly ItemValidator _itemValidator = new();
    private readonly PurchaseOrderApplicationService _poApplicationService = new();
    [Fact]
    public void ShouldCreateItem()
    {
      // Given a Good("BNNA1", "Banana"), Quantity = 1, and Price = 50
      var good = new Good("BNNA1", "Banana");
      var quantity = 1;
      var price = 50;
      // When the Item is created
      var item = new Item(good, quantity, price);
      // Then the item should exist
      Assert.NotNull(item);
      Assert.Equal(quantity, item.Quantity);
      Assert.Equal(price, item.Price);
    }
    [Fact]
    public void ShouldCreatePurchase()
    {
      // Given a number = 1215 and Supplier("BCDSA", "PEN", 2) and
      // Items [Item(Good("CRKOO", "Cookie"), 2, 5), Item(Good("ZRKOU", "Zoo Keeper"), 1, 6)]
      var supplier = new Supplier("BCDSA", "PEN", 2);
      var item1 = new Item(new Good("CRKOO", "Cookie"), 2, 5);
      var item2 = new Item(new Good("ZRKOU", "Zoo Keeper"), 1, 6);
      // When the purchase order is created
      var purchaseOrder = new PurchaseOrder(supplier,new List<Item> { item1, item2});
      purchaseOrder.Add(item1);
      purchaseOrder.Add(item2);
      TimeSpan calculatedLeadTime =  purchaseOrder.EstimatedDeliveryDate- purchaseOrder.OrderDate;
      // Then it should exist
      Assert.NotNull(purchaseOrder);
      Assert.Equal(supplier, purchaseOrder.Supplier);
      Assert.Equal(2, purchaseOrder.Items.Count());
      Assert.Equal(calculatedLeadTime.Days, supplier.LeadTime);
    }

    [Fact]
    public void ShouldValidatePurchaseOrder()
    {
      // Given the number, supplier, and item list
      var supplier = new Supplier("ABCDA", "Ab", 3);
      var good = new Good("WEARV", "Wearing Clothe");
      var item = new Item(good, 2, 50.52m);
      // When validating
      var purchaseOrder = new PurchaseOrder(supplier, new List<Item> { item});
      purchaseOrder.Add(item);

      var validate = _validator.Validate(purchaseOrder);
      // Then it should validate
      Assert.True(validate.IsValid);

    }

    [Fact]
    public void ShouldValidateItem()
    {
      var good = new Good("HAIR1", "Hair cuts");
      var item = new Item(good, 3, 50.30m);
      var validate = _itemValidator.Validate(item);
      Assert.True(validate.IsValid);

    }

    [Fact]
    public void ShouldNotValidateInvalidItem()
    {
      var good = new Good("HAIR", "Hair cuts");
      var item = new Item(good, 3, 50.30m);
      var validate = _itemValidator.Validate(item);
      Assert.False(validate.IsValid);
    }

    [Fact]
    public void ShouldNotValidateInvalidPurchaseOrder2()
    {
      // Given the number, supplier, and item list...giving inValid number=0
      // and inValid item Quantity = 0
      var supplier = new Supplier("ABCDA", "Ab", 3);
      var good = new Good("WEARV", "Wearing Clothe");
      var item = new Item(good, 0, 50.52m);
      // When validating
      var purchaseOrder = new PurchaseOrder( supplier, new List<Item> { item});
      purchaseOrder.Add(item);

      var validate = _validator.Validate(purchaseOrder);
      // Then it should validate
      Assert.False(validate.IsValid);
    }

    [Fact]
    public async Task ShouldFindPurchaseOrderByNumber()
    {
      // Given an existing number of purchase order by number=112
      var number = 1;
      // When looking for the purchase order in the appliation server
      var purchaseOrder = await _poApplicationService.FindPurchaseOrderAsync(number);
      // Then the purchase order should exist in the application service
      Assert.NotNull(purchaseOrder);
      Assert.Equal(number, purchaseOrder.Number);

    }
    [Fact]
    public async Task ShouldNotFindPurchaseOrderByNumber()
    {
      // Given an number of a non-existing purchase order by number=112
      var number = 11;
      // When looking for the purchase order in the appliation server
      var purchaseOrder = await _poApplicationService.FindPurchaseOrderAsync(number);
      // Then the purchase order should not exist in the application service
      Assert.Null(purchaseOrder);

    }
    [Fact]
    public async Task ShouldAddPurchaseOrder()
    {
      //Give the  supplier, list of items
      var supplier = new Supplier("ABCDA", "Ab", 3);
      var good = new Good("WEARV", "Wearing Clothe");
      var item = new Item(good, 2, 50.52m);
      // When validating
      var purchaseOrder = new PurchaseOrder( supplier, new List<Item> { item });
      
      purchaseOrder.Add(item);
      
      // When adding to the purchase order
      var addToPurchases = await _poApplicationService.AddPurchaseOrderAsync(purchaseOrder);
      //Then the purchase order should exist
      Assert.True(addToPurchases);
      var find = await _poApplicationService.FindPurchaseOrderAsync(purchaseOrder.Number);
      Assert.NotNull(find);
      Assert.Equal(purchaseOrder.Number, find.Number);

    }

    [Fact]
    public async Task ShouldAddItemsToExistingPurchaseOrder()
    {
      // Given the purchase order number=112 and list of items [Item(), Item()]
      var number = 1;
      var item1 = new Item(new Good("THEE1", "The Flash"), 1, 150.00m);
      var item2 = new Item(new Good("THEE2", "The Cash"), 5, 85.52m);
      // When added to the purchase order
      var find = await _poApplicationService.FindPurchaseOrderAsync(number);
      var appendPurchase = await _poApplicationService.AddToExistingAsync(find, new List<Item>() { item1, item2});
      // Then the purchase order should have the added items
      Assert.True(appendPurchase);
    }

    [Fact]
    public void ShouldAddQuantityOfSimilarItems() 
    {
      // Given a supplier, items with similar good
      var supplier = new Supplier("BCDSA", "PEN", 2);
      var item1 = new Item(new Good("POPOT", "Cookie"), 2, 5);
      var item2 = new Item(new Good("POPOT", "Cookie"), 1, 6);
      var item3 = new Item(new Good("POPOT", "Cookie"), 3, 5);
      var item4 = new Item(new Good("HUTUI", "Cookie"), 1, 6);
      // When the purchase order is created, and items added to the purchase order
      var purchaseOrder = new PurchaseOrder(supplier, new List<Item> { item1 });
      purchaseOrder.Add(item2);
      purchaseOrder.Add(item3);
      purchaseOrder.Add(item4);
      // Then the purchase order ITEMS Quantity should increase by number of quantity provided 
      Assert.True(purchaseOrder.Items.Count() == 2);
      Assert.Equal(6, purchaseOrder.Items.ElementAt(0).Quantity);
    }

    [Fact]
    public async Task ShouldCancelPurchaseOrder()
    {
      // Given the purchase order number
      var number = 1;
      var findCanceledOrder = await _poApplicationService.FindPurchaseOrderAsync(number);
      Assert.True(findCanceledOrder.Active);
      // When canceling the purchase order in the application service
      var cancelOrder = await _poApplicationService.CancelOrderAsync(number);
      // Then the purchase order should not exist on the application service
      Assert.True(cancelOrder);
      var findCanceledOrder2 = await _poApplicationService.FindPurchaseOrderAsync(number);
      Assert.False(findCanceledOrder2.Active);
    }

    [Fact]
    public async Task ShouldListPurchaseOrder()
    {
      // Given Application Service with at least 1 item
      var number = 1;
      // When fetch the purchase order list from the AS
      var purchaseOrder = await _poApplicationService.GetPurchaseList();
      var findPurchaseOrder = await _poApplicationService.FindPurchaseOrderAsync(number);
      //Then purchase order should at leaset have 1 item
      Assert.True(findPurchaseOrder.Active);
      Assert.Contains(purchaseOrder, n=> n.Number == number);
      Assert.True(purchaseOrder.Count()>0);
    }
  }
}
