﻿using FluentResults;
using FluentValidation;
using KRSPurchase.Domain;

namespace KRSPurchase.ApplicationServices
{
  public abstract class BaseApplicationServices<TDomain, TValidator> where TDomain : class, Entity where TValidator : AbstractValidator<TDomain>, new()
  {
    protected readonly IBaseRepository<TDomain> _repository;
    private readonly TValidator _validator = new();

    public BaseApplicationServices(IBaseRepository<TDomain> repository)
    {
      _repository = repository;
    }

    public async Task<Result<TDomain>> FindByCode(string code)
    {
      if (code == string.Empty) return Result.Fail<TDomain>("Code cannot be empty");
      var tResult = await _repository.FindByCode(code);
      if (tResult is null) return Result.Fail<TDomain>("Code cannot be found");

      var tValidation = _validator.Validate(tResult);
      return (!tValidation.IsValid) 
        ? Result.Fail<TDomain>("Code not valid")
        : Result.Ok(tResult);
    }

    public async Task<Result<IList<TDomain>>> ListAll()
      => Result.Ok(await _repository.ListAll());

    public async Task<Result<string>> AddAsync(TDomain tDomain)
    {
      var validationResult = _validator.Validate(tDomain);
      var checkDuplicate = await CheckDuplicate(tDomain.Code);

      if (!validationResult.IsValid)
        return Result.Fail(validationResult.Errors.Select(e => e.ErrorMessage));

      return (checkDuplicate)
        ? Result.Fail<string>("Product already exists")
        : Result.Ok(await _repository.AddAsync(tDomain));
    }

    public async Task<Result<bool>> EditAsync(TDomain tDomain)
    {
      var existingProduct = await _repository.FindByCode(tDomain.Code);
      if (existingProduct == null) return Result.Fail<bool>("Product not found");

      var validate = _validator.Validate(existingProduct);
      if (!validate.IsValid) return Result.Fail<bool>(validate.Errors.Select(v => v.ErrorMessage));

      if (existingProduct == null) return false;
      var editedProduct = await _repository.EditAsync(tDomain);
      return Result.Ok(editedProduct);
    }

    public async Task<Result<bool>> DeleteAsync(string code)
    {
      var product = await _repository.FindByCode(code);
      return (product is null) 
        ? Result.Fail<bool>("Product not found")
        : Result.Ok(await _repository.DeleteAsync(code));
    }

    public async Task<bool> CheckDuplicate(string code)
     => await _repository.FindByCode(code)  is not null;
  }
}
