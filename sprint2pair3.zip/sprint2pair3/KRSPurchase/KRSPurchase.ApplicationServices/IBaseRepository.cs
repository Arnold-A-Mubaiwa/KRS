﻿using KRSPurchase.Domain;

namespace KRSPurchase.ApplicationServices
{
  public interface IBaseRepository<TDomain>
  {
    public Task<TDomain> FindByCode(string code);
    public Task<IList<TDomain>> ListAll();
    public Task<string> AddAsync(TDomain tDomain);
    public Task<bool> EditAsync(TDomain tDomain);
    public Task<bool> DeleteAsync(string code);
  }
}
