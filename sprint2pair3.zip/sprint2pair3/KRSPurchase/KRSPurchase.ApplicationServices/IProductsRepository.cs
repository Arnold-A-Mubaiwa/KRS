﻿using KRSPurchase.Domain;
namespace KRSPurchase.ApplicationServices
{
  public interface IProductsRepository:IBaseRepository<Product>
  {
  }
}
