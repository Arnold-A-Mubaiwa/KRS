﻿using KRSPurchase.Domain;
namespace KRSPurchase.ApplicationServices
{
  public interface IProductsRepository
  {
    public Task<IList<Product>> ListProducts();
    public Task<Product> FindAsync(string code);
    public Task<string> AddAsync(Product product);
    public Task<bool> EditAsync(Product existingProduct);
    public Task<bool> DeleteAsync(string code);
  }
}
