﻿using KRSPurchase.Domain;

namespace KRSPurchase.ApplicationServices
{
  public interface ISuppliersRepository : IBaseRepository<Supplier>
  {
  }
}
