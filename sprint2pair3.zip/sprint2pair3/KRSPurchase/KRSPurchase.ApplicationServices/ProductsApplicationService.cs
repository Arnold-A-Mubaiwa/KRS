﻿using FluentResults;
using KRSPurchase.Domain;

namespace KRSPurchase.ApplicationServices
{
  public class ProductsApplicationService
  {
    private readonly ProductValidator _validator = new();
    private readonly IProductsRepository _productsRepository;

    public ProductsApplicationService(IProductsRepository repository)
    {
      _productsRepository = repository;
    }
    public async Task<Result<string>> AddAsync(Product product)
    {
      var validationResult = _validator.Validate(product);
      var checkDuplicate = await CheckDuplicate(product.Code);

      if (!validationResult.IsValid)
        return Result.Fail(validationResult.Errors.Select(e => e.ErrorMessage));

      var addedCode = await _productsRepository.AddAsync(product);
      return Result.Ok(addedCode);
    }

    public async Task<Result<Product>> FindAsync(string code)
    {
      var productFound = await _productsRepository.FindAsync(code)!;
      return Result.Ok(productFound);
    }

    public async Task<bool> DeleteAsync(string code)
    {
      var product = await FindAsync(code);
      if (product == null) return false;

      return await _productsRepository.DeleteAsync(code);
    }

    public async Task<bool> EditAsync(Product product)
    {
      var existingProduct = (await FindAsync(product.Code)).Value;
      var validate = _validator.Validate(existingProduct);

      if (!validate.IsValid || existingProduct == null) return false;
      return await _productsRepository.EditAsync(product);
    }

    public async Task<Result<IList<Product>>> ListProducts()
    {
      var products = await _productsRepository.ListProducts();
      return Result.Ok(products);
    }

    private async Task<bool> CheckDuplicate(string code)
    {
      var product = await FindAsync(code);
      return (product != null);
    }
  }
}