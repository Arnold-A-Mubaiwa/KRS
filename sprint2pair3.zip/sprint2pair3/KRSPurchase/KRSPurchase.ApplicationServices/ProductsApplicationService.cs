﻿using FluentResults;
using KRSPurchase.Domain;

namespace KRSPurchase.ApplicationServices
{
  public class ProductsApplicationService:BaseApplicationServices<Product, ProductValidator>
  {
    public ProductsApplicationService(IProductsRepository repository) : base(repository) 
    {
    }
  }
}