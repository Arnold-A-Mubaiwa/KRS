﻿using KRSPurchase.Domain;

namespace KRSPurchase.ApplicationServices
{
  public class SupplierApplicationServices
  {
    private List<Supplier> _suppliers = new List<Supplier>()
    { 
      new Supplier("GTYAR", "Yaris", 2),
      new Supplier("REDDR", "Redragon", 5),
      new Supplier("AGILE", "Scrumscxi", 1),
      new Supplier("GIELS", "Genetics", 2),
    };
    private SupplierValidator _validator = new();


    public async Task<Supplier> FindSupplierAsync(string code)
    {
      return _suppliers.FirstOrDefault(s => s.Code == code)!;
    }

    public async Task<bool> AddSupplierAsync(Supplier supplier)
    {
      var validate = _validator.Validate(supplier);
      var checkDuplicate = await CheckDuplicateAsync(supplier);
      if (!validate.IsValid || checkDuplicate) return false;
      _suppliers.Add(supplier);
      return true;
    }

    public async Task<bool> EditSupplierAsync(Supplier supplier)
    {
      var validate = _validator.Validate(supplier);
      if (!validate.IsValid || supplier == null) return false;

      _suppliers = _suppliers.Select(s => supplier.Code == s.Code ? supplier : s).ToList(); 
      return true;
    }
    public async Task<bool> DeleteSupplierAsync(Supplier supplier)
    {
      var existingSupplier = await FindSupplierAsync(supplier.Code);
      if (existingSupplier == null) return false;
      _suppliers.Remove(supplier);
      return true;
    }

    public async Task<List<Supplier>> ListSuppliersAsync()
    {
      return _suppliers;
    }
    public async Task<bool> CheckDuplicateAsync(Supplier supplier)
    {
      var checkSupplier = await FindSupplierAsync(supplier.Code);
      return checkSupplier != null;
    }
   }
}
