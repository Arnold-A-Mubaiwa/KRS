﻿using FluentResults;
using KRSPurchase.Domain;

namespace KRSPurchase.ApplicationServices
{
  public class SuppliersApplicationServices:BaseApplicationServices<Supplier, SupplierValidator>
  {
    public SuppliersApplicationServices(ISuppliersRepository repository) : base(repository)
    {
    }
   }
}
