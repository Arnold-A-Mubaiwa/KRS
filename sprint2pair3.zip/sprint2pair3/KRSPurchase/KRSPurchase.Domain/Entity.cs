﻿namespace KRSPurchase.Domain
{
  public interface Entity
  {
    string Code { get; }
  }
}