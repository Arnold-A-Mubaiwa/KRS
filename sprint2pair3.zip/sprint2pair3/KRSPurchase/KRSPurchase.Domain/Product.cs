﻿namespace KRSPurchase.Domain
{
  public class Product : Entity
  {
    public string Code { get; }
    public string Name { get; set; }
    public Product(string code, string name)
    {
      Code = code;
      Name = name;
    }
  }
}