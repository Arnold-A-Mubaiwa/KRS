﻿namespace KRSPurchase.Domain
{
  public class Product
  {
    public string Code { get; }
    public string Name { get; set; }
    public Product(string code, string name)
    {
      Code = code;
      Name = name;
    }
  }
}