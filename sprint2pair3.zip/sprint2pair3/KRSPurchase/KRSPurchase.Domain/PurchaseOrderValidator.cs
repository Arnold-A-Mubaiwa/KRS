﻿using FluentValidation;

namespace KRSPurchase.Domain
{
  public class PurchaseOrderValidator : AbstractValidator<PurchaseOrder>
  {
    public PurchaseOrderValidator()
      {
      RuleFor(p => p.Number).NotEmpty().GreaterThan(0);
      RuleFor(p => p.OrderDate).NotEmpty();
      RuleFor(p => p.Supplier).SetValidator(new SupplierValidator());
      RuleForEach(p => p.Items).SetValidator(new ItemValidator());
      RuleFor(p => p.Items).NotEmpty();
      }
  }
}
