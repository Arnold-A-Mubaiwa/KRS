﻿namespace KRSPurchase.Domain
{
  public class Supplier : Entity
  {
    public string Code { get; }

    public string Name { get; set; }

    public int LeadTime { get; set; }

    public Supplier(string code, string name, int leadTime)
    {
      Code = code;
      Name = name;
      LeadTime = leadTime;
    }
  }
}
