using KRSPurchase.ApplicationServices;
using KRSPurchase.Domain;
using KRSPurchase.Tests.MockRepositories;

namespace KRSPurchase.Tests
{
  public class ManageProducts
  {
    private readonly ProductsApplicationService _service = new(new MockProductsRepository());
    private readonly ProductValidator _validator = new();

    [Fact]
    public void ShouldCreateProduct()
    {
      //Given product name = "DELL" and code = "VPROM" 
      var name = "DELL";
      var code = "VPROM";
      //When create product 
      var product = new Product(code, name);
      //Then product should exist
      Assert.NotNull(product);
      Assert.Equal(name, product.Name);
      Assert.Equal(product.Code, code);
    }

    [Fact]
    public async Task ShouldAddProduct()
    {
      //Give Product name="BOTTLE" code="BOT22"
      var product = new Product("BOT22", "BOTTLE");
      //When  Product is Added to the application Service
      var (isSuccess, isFail, addedCode, errors) = await _service.AddAsync(product);

      Assert.True(isSuccess);
      Assert.False(isFail);
      Assert.Null(errors);
      var addedProduct = (await _service.FindAsync(addedCode)).Value;
      //Then the product exists
      Assert.Equal("BOT22", addedProduct.Code);
    }

    [Fact]
    public async Task ShouldFindProductByCode()
    {
      //Given Product by code = "CHAIR"
      var code = "CHAIR";
      //WHEN we find code
      var product = (await _service.FindAsync(code)).Value;
      //Then the product exists
      Assert.Equal(code, product.Code);
    }

    [Fact]
    public void ShouldValidateValidProduct()
    {
      // Given product with name="MARKER" and code = "PMERK"
      var product = new Product("PMERK", "MARKER");
      // When we validate the product 
      var validate = _validator.Validate(product);
      //Then the product is valid
      Assert.True(validate.IsValid);
    }

    [Fact]
    public void ShouldValidateInvalideProduct()
    {
      // Given invalid product with code = "PMEK" and name = ""
      var product = new Product("PMEK", "");
      // When we validate the product 
      var validate = _validator.Validate(product);
      //Then the product is inValid
      Assert.False(validate.IsValid);
    }

    [Fact]
    public async Task ShouldDeleteProduct()
    {
      // Given an existing product with code = "F2431"
      var code = "F2431";
      // When deleting the product
      var productDeleted = await _service.DeleteAsync(code);
      // Then the product should be deleted
      Assert.True(productDeleted);
      var findProduct = (await _service.FindAsync(code)).Value;
      Assert.Null(findProduct);
    }

    [Fact]
    public async Task ShouldEditProduct()
    {
      // Given the code = "PRJTR", name = "Projecter" of an existing Product
      var code = "PRJTR";
      var name = "Projectors";
      var existingProduct = (await _service.FindAsync(code)).Value;
      // When editing the product
      existingProduct.Name = name;
      var newProduct = await _service.EditAsync(existingProduct);
      var edittedProduct = (await _service.FindAsync(code)).Value;
      //Then the product should be edited
      Assert.True(newProduct);
      Assert.Equal(name, edittedProduct.Name);
    }

    [Fact]
    public async Task ShouldListProduct()
    {
      // Given an Application Service with at least 1 product
      var existingProductCode = "KYBRD";
      // When listing the products
      var (isSuccess, isFail, listProducts, errors) = await _service.ListProducts();
      // Then the AS should have at least 1 product
      Assert.True(isSuccess);
      Assert.False(isFail);
      Assert.Null(errors);
      Assert.Contains(listProducts, p => p.Code == existingProductCode);
      Assert.True(listProducts.Count > 1);
    }

    [Fact]
    public async Task ShouldFailAdd()
    {
      // Given the product
      var product = new Product("PRJT", "BOTTLE2");
      // When the product has duplicate
      var (isSuccess, isFail, addedCode, errors) = await _service.AddAsync(product);
      Assert.True(isFail);
      Assert.False(isSuccess);
      Assert.NotNull(errors);
      var findAddedCode = (await _service.FindAsync(addedCode)).Value;
      // Then the product shouldn't be added
      Assert.Null(findAddedCode);
    }
  }
}