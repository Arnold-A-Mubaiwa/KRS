﻿using KRSPurchase.ApplicationServices;
using KRSPurchase.Domain;
using KRSPurchase.Tests.MockRepositories;

namespace KRSPurchase.Tests
{
  public class ManageSuppliers
  {
    private readonly SuppliersApplicationServices _service = new (new MockSuppliersRepository());
    private readonly SupplierValidator _validator = new ();

    [Fact]
    public void ShouldCreateSupplier()
    {
      // Given a supplier with code="HYJUK", name="Humbler", leadTime=2 (days)
      var code = "HYJUK";
      var name = "Humbler";
      var leadTime = 2;
      // When we create a new Supplier
      var supplier = new Supplier(code, name, leadTime);
      // The supplier should exist
      Assert.NotNull(supplier);
      Assert.Equal(code, supplier.Code);
      Assert.Equal(name, supplier.Name);
      Assert.Equal(leadTime, supplier.LeadTime);
    }

    [Fact] 
    public void ShouldValidateAValidSupplier() 
    {
      // Given a supplier with code="BYPAS", name="Bipolors", leadtime=2
      var supplier = new Supplier("BYPAS", "Bipolors", 2);
      // When the supplier is validated
      var validate = _validator.Validate(supplier);
      // Then the supplier is Valid
      Assert.True(validate.IsValid);
    }

    [Fact]
    public void ShouldValidateAnInValidSupplier()
    {
      // Given a supplier with code="PERME", name="Permanent", leadtime=-1
      var supplier = new Supplier("PERME", "Permanent", -1);
      // When the supplier is validated
      var validated = _validator.Validate(supplier);
      // Then the supplier is Valid
      Assert.False(validated.IsValid);
    }

    [Fact]
    public async Task ShouldFindbyCode()
    {
      // Given a supplier with code "GTYAR"
      var code = "GTYAR";
      // When finding a already existing supplier in the AppService
      var supplier = await _service.FindByCode(code);
      // Then the supplier should exist
      Assert.NotNull(supplier);
    }

    [Fact]
    public async Task ShouldAddSupplierAsync()
    {
      // Given a supplier with code="REDDR", name="Redragon", leadtime=5
      var supplier = new Supplier("REDDh", "Redragon", 3);
      // When a supplier added to the application service
      var (isSuccess, isFail, isSupplierAdded, errors) = await _service.AddAsync(supplier);
      // Then the supplier should exist on the App Servcice
      Assert.True(isSuccess);
      Assert.False(isFail);
      Assert.Equal(supplier.Code,isSupplierAdded);
      Assert.Null(errors);
      var addedSupplier = (await _service.FindByCode(supplier.Code)).Value;
      Assert.NotNull(addedSupplier);
      Assert.Equal(supplier.Code, addedSupplier.Code);
      
    }

    [Fact]
    public async Task ShouldEditSupplierAsync()
    {
      // Given an existing supplier with code="AGILE", name="Scrum", leadTime=5
      var supplier = new Supplier("AGILE", "Scrum", 5);
      // When supplier is edited on the application service
      var (isSuccess, isFail, isSupplierEdited, errors) = await _service.EditAsync(supplier);
      Assert.True(isSuccess);
      Assert.False(isFail);
      Assert.Null(errors);
      Assert.True(isSupplierEdited);
      // Then the edited supplier should exist with new name and leadtime
      var editedSupplier = (await _service.FindByCode(supplier.Code)).Value;
      Assert.Equal(supplier.Name, editedSupplier.Name);
      Assert.Equal(supplier.LeadTime, editedSupplier.LeadTime); 
    }

    [Fact]
    public async Task ShouldEditSupplierNameAsync()
    {
      // Given an existing supplier with code="AGILE", new name="Scrum"
      var code = "AGILE";
      var name = "Scrum";
      var supplier = (await _service.FindByCode(code)).Value;
      supplier.Name = name;
      // When supplier is edited on the application service
      var (isSuccess, isFail, isSupplierEdited, errors) = await _service.EditAsync(supplier);
      Assert.True(isSuccess);
      Assert.False(isFail);
      Assert.Null(errors);
      Assert.True(isSupplierEdited);
      // Then the edited supplier should exist with new name and leadtime
      var editedSupplier = (await _service.FindByCode(supplier.Code)).Value;
      Assert.Equal(supplier.Name, editedSupplier.Name);
    }

    [Fact]
    public async Task ShouldEditSupplierLeadTimeAsync()
    {
      // Given an existing supplier with code="AGILE", new leadTime=6
      var code = "AGILE";
      var leadTime = 6;
      var supplier = (await _service.FindByCode(code)).Value;
      supplier.LeadTime = leadTime;
      // When supplier is edited on the application service
      var (isSuccess, isFail, isSupplierEdited, errors) = await _service.EditAsync(supplier);
      Assert.True(isSuccess);
      Assert.False(isFail);
      Assert.Null(errors);
      Assert.True(isSupplierEdited);
      // Then the edited supplier should exist with name and new leadtime
      var editedSupplier = (await _service.FindByCode(supplier.Code)).Value;
      Assert.Equal(supplier.LeadTime, editedSupplier.LeadTime);
    }

    [Fact]
    public async Task ShouldDeleteAnExistingSupplierAsync()
    {
      // Given an existing suppier with code="GIELS"
      var code = "GIELS";
      var existingSupplier = await _service.FindByCode(code);
      Assert.True(existingSupplier.IsSuccess);
      // When supplier is deleted on the application service
      var (isSuccess, isFail, isSupplierDeleted, errors) = await _service.DeleteAsync(code);
      Assert.True(isSuccess);
      Assert.False(isFail);
      Assert.Null(errors);
      Assert.True(isSupplierDeleted);
      // Then the supplier should not exist
      var deletedSupplier = await _service.FindByCode(code);
      Assert.False(deletedSupplier.IsSuccess); 
    }

    [Fact]
    public async Task ShouldListSuppliersAsync()
    {
      // Given a AS with at least 1 supplier
      var code = "REDDR";
      // When we fetch the list from AS
      var (isSuccess, isFail, listOfSuppliers, errors) = await _service.ListAll();
      //var supple = await _service.FindSupplierAsync(code);
      // Then the list should have at least 1 supplier
      Assert.True(isSuccess);
      Assert.False(isFail);
      Assert.Null(errors);
      Assert.Contains(listOfSuppliers, s => s.Code == code);
      Assert.True(listOfSuppliers.Count > 1);
    }

    [Fact]
    public async Task ShouldCheckDuplicates()
    {
      // Give a supplier
      var supplier = new Supplier("GIELS", "Genetics", 2);
      // When checking for duplicates 
      var checkDuplicate = await _service.CheckDuplicate(supplier.Code);
      // Then the supplier should exists
      Assert.True(checkDuplicate);
    }

    [Fact]
    public async Task ShouldCheckDuplicateBeforeAdd()
    {
      // Given an already existing supplier with code="REDDR", name="Redragon", leadtime=5
      var supplier = new Supplier("REDDR", "Redragon", 5);

      // When a supplier is added to the application service
      var (isSuccess, isFail, isSupplierAdded, errors) = await _service.AddAsync(supplier);
      // Then the supplier shouldn't be added to the Application Service if it's duplicate
      Assert.False(isSuccess);
      Assert.True(isFail);
      Assert.NotNull(errors);
      Assert.Null(isSupplierAdded);
    }
  }
}
