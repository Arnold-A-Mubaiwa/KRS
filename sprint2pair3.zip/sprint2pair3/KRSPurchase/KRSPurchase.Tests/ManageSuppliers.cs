﻿using KRSPurchase.ApplicationServices;
using KRSPurchase.Domain;

namespace KRSPurchase.Tests
{
  public class ManageSuppliers
  {
    private readonly SupplierApplicationServices _service = new ();
    private readonly SupplierValidator _validator = new ();

    [Fact]
    public void ShouldCreateSupplier()
    {
      // Given a supplier with code="HYJUK", name="Humbler", leadTime=2 (days)
      var code = "HYJUK";
      var name = "Humbler";
      var leadTime = 2;
      // When we create a new Supplier
      var supplier = new Supplier(code, name, leadTime);
      // The supplier should exist
      Assert.NotNull(supplier);
      Assert.Equal(code, supplier.Code);
      Assert.Equal(name, supplier.Name);
      Assert.Equal(leadTime, supplier.LeadTime);
    }

    [Fact] 
    public void ShouldValidateAValidSupplier() 
    {
      // Given a supplier with code="BYPAS", name="Bipolors", leadtime=2
      var supplier = new Supplier("BYPAS", "Bipolors", 2);
      // When the supplier is validated
      var validate = _validator.Validate(supplier);
      // Then the supplier is Valid
      Assert.True(validate.IsValid);
    }

    [Fact]
    public void ShouldValidateAnInValidSupplier()
    {
      // Given a supplier with code="PERME", name="Permanent", leadtime=-1
      var supplier = new Supplier("PERME", "Permanent", -1);
      // When the supplier is validated
      var validated = _validator.Validate(supplier);
      // Then the supplier is Valid
      Assert.False(validated.IsValid);
    }

    [Fact]
    public async Task ShouldFindbyCode()
    {
      // Given a supplier with code "GTYAR"
      var code = "GTYAR";
      // When finding a already existing supplier in the AppService
      var supplier = await _service.FindSupplierAsync(code);
      // Then the supplier should exist
      Assert.NotNull(supplier);
      Assert.Equal(code, supplier.Code);
    }

    [Fact]
    public async Task ShouldAddSupplierAsync()
    {
      // Given a supplier with code="REDDR", name="Redragon", leadtime=5
      var supplier = new Supplier("REDDh", "Redragon", 3);
      // When a supplier added to the application service
      var isSupplierAdded = await _service.AddSupplierAsync(supplier);
      // Then the supplier should exist on the App Servcice
      Assert.True(isSupplierAdded);

      var addedSupplier = await _service.FindSupplierAsync(supplier.Code);
      Assert.NotNull(addedSupplier);
      Assert.Equal(supplier.Code, addedSupplier.Code);
      
    }

    [Fact]
    public async Task ShouldEditSupplierAsync()
    {
      // Given an existing supplier with code="AGILE", name="Scrum", leadTime=5
      var supplier = new Supplier("AGILE", "Scrum", 5);
      // When supplier is edited on the application service
      var isSupplierEdited = await _service.EditSupplierAsync(supplier);
      Assert.True(isSupplierEdited);
      // Then the edited supplier should exist with new name and leadtime
      var editedSupplier = await _service.FindSupplierAsync(supplier.Code);
      Assert.Equal(supplier.Name, editedSupplier.Name);
      Assert.Equal(supplier.LeadTime, editedSupplier.LeadTime); 
    }

    [Fact]
    public async Task ShouldEditSupplierNameAsync()
    {
      // Given an existing supplier with code="AGILE", new name="Scrum"
      var code = "AGILE";
      var name = "Scrum";
      var supplier = await _service.FindSupplierAsync(code);
      supplier.Name = name;
      // When supplier is edited on the application service
      var isSupplierEdited = await _service.EditSupplierAsync(supplier);
      Assert.True(isSupplierEdited);
      // Then the edited supplier should exist with new name and leadtime
      var editedSupplier = await _service.FindSupplierAsync(supplier.Code);
      Assert.Equal(supplier.Name, editedSupplier.Name);
    }

    [Fact]
    public async Task ShouldEditSupplierLeadTimeAsync()
    {
      // Given an existing supplier with code="AGILE", new leadTime=6
      var code = "AGILE";
      var leadTime = 6;
      var supplier = await _service.FindSupplierAsync(code);
      supplier.LeadTime = leadTime;
      // When supplier is edited on the application service
      var isSupplierEdited = await _service.EditSupplierAsync(supplier);
      Assert.True(isSupplierEdited);
      // Then the edited supplier should exist with name and new leadtime
      var editedSupplier = await _service.FindSupplierAsync(supplier.Code);
      Assert.Equal(supplier.LeadTime, editedSupplier.LeadTime);
    }

    [Fact]
    public async Task ShouldDeleteAnExistingSupplierAsync()
    {
      // Given an existing suppier with code="GIELS"
      var code = "GIELS";
      var existingSupplier = await _service.FindSupplierAsync(code);
      // When supplier is deleted on the application service
      var isSupplierDeleted = await _service.DeleteSupplierAsync(existingSupplier);
      Assert.True(isSupplierDeleted);
      // Then the supplier should not exist
      var deletedSupplier = await _service.FindSupplierAsync(code);
      Assert.Null(deletedSupplier); 
    }

    [Fact]
    public async Task ShouldListSuppliersAsync()
    {
      // Given a AS with at least 1 supplier
      var code = "REDDR";
      // When we fetch the list from AS
      var listOfSuppliers = await _service.ListSuppliersAsync();
      //var supple = await _service.FindSupplierAsync(code);
      // Then the list should have at least 1 supplier
      Assert.Contains(listOfSuppliers, s => s.Code == code);
      Assert.True(listOfSuppliers.Count > 1);
    }

    [Fact]
    public async Task ShouldCheckDuplicates()
    {
      // Give a supplier
      var supplier = new Supplier("GIELS", "Genetics", 2);
      // When checking for duplicates 
      var checkDuplicate = await _service.CheckDuplicateAsync(supplier);
      // Then the supplier should exists
      Assert.True(checkDuplicate);
    }

    [Fact]
    public async Task ShouldCheckDuplicateBeforeAdd()
    {
      // Given an already existing supplier with code="REDDR", name="Redragon", leadtime=5
      var supplier = new Supplier("REDDR", "Redragon", 5);

      // When a supplier is added to the application service
      var isSupplierAdded = await _service.AddSupplierAsync(supplier);
      // Then the supplier shouldn't be added to the Application Service if it's duplicate
      Assert.False(isSupplierAdded);
    }
  }
}
