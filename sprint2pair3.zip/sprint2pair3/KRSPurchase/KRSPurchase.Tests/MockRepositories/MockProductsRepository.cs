﻿using KRSPurchase.Domain;
using KRSPurchase.ApplicationServices;

namespace KRSPurchase.Tests.MockRepositories
{
  public class MockProductsRepository : IProductsRepository
  {
    private List<Product> _products = new List<Product>()
    {
      new Product("KYBRD", "Keyboard"),
      new Product("PRJTR", "Projecter"),
      new Product("CHAIR", "Chair"),
      new Product("F2431", "Laptop"),
    };

    public async Task<IList<Product>> ListAll()
      => _products;

    public async Task<Product> FindByCode(string code)
      => _products.FirstOrDefault(p => p.Code == code)!;

    public async Task<string> AddAsync(Product product)
    {
      _products.Add(product);
      return product.Code;
    }

    public async Task<bool> EditAsync(Product existingProduct)
    {
      _products = _products.Select(p => p.Code == existingProduct.Code ? existingProduct : p).ToList();
      return true;
    }

    public async Task<bool> DeleteAsync(string code)
    {
      var product = await FindByCode(code);
      if (product == null) return false;

      _products.Remove(product);
      return true;
    }
  }
}