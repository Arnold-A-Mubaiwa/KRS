﻿using KRSPurchase.Domain;
using KRSPurchase.ApplicationServices;

namespace KRSPurchase.Tests.MockRepositories
{
  public class MockProductsRepository : IProductsRepository
  {
    private List<Product> _products = new List<Product>()
    {
      new Product("KYBRD", "Keyboard"),
      new Product("PRJTR", "Projecter"),
      new Product("CHAIR", "Chair"),
      new Product("F2431", "Laptop"),
    };

    public async Task<IList<Product>> ListProducts()
    {
      return _products;
    }

    public async Task<Product> FindAsync(string code)
    {
      return _products.FirstOrDefault(p => p.Code == code)!;
    }

    public async Task<string> AddAsync(Product product)
    {
      _products.Add(product);
      return product.Code;
    }

    public async Task<bool> EditAsync(Product existingProduct)
    {
      _products = _products.Select(p => p.Code == existingProduct.Code ? existingProduct : p).ToList();
      return true;
    }

    public async Task<bool> DeleteAsync(string code)
    {
      var product = await FindAsync(code);
      if (product == null) return false;

      _products.Remove(product);
      return true;
    }
  }
}