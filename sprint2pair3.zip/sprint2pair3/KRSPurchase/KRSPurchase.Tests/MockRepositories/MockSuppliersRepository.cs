﻿using KRSPurchase.ApplicationServices;
using KRSPurchase.Domain;

namespace KRSPurchase.Tests.MockRepositories
{
  public class MockSuppliersRepository : ISuppliersRepository
  {
    private List<Supplier> _suppliers = new List<Supplier>()
    {
      new Supplier("GTYAR", "Yaris", 2),
      new Supplier("REDDR", "Redragon", 5),
      new Supplier("AGILE", "Scrumscxi", 1),
      new Supplier("GIELS", "Genetics", 2),
    };
    private SupplierValidator _validator = new();


    public async Task<Supplier> FindByCode(string code)
      => _suppliers.FirstOrDefault(s => s.Code == code)!;

    public async Task<string> AddAsync(Supplier supplier)
    {
      _suppliers.Add(supplier);
      return supplier.Code;
    }

    public async Task<bool> EditAsync(Supplier supplier)
    {
      var validate = _validator.Validate(supplier);
      if (!validate.IsValid || supplier == null) return false;

      _suppliers = _suppliers.Select(s => supplier.Code == s.Code ? supplier : s).ToList();
      return true;
    }

    public async Task<bool> DeleteAsync(string code)
    {
      var existingSupplier = await FindByCode(code);
      if (existingSupplier == null) return false;
      _suppliers.Remove(existingSupplier);
      return true;
    }

    public async Task<IList<Supplier>> ListAll()
      => _suppliers;
  
  }
}

