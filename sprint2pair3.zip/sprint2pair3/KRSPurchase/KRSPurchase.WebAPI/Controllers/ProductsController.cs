﻿using KRSPurchase.ApplicationServices;
using KRSPurchase.WebApi.Extensions;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace KRSPurchase.WebAPI.Controllers
{
  [Route("api/[controller]")]
  [ApiController]
  public class ProductsController : ControllerBase
  {
    private readonly ProductsApplicationService _service;

    public ProductsController(ProductsApplicationService service) 
    { 
      _service = service;
    }
    // GET: api/<ProductsController>
    [HttpGet]
    public async Task<IActionResult> Get()
    {
      var products = await _service.ListProducts();
      return products.ToActionResult(Request.HttpContext);
    }

    // GET api/<ProductsController>/{code}
    [HttpGet("{code}")]
    public async Task<IActionResult> Get(string code)
    {
      var product = await _service.FindAsync(code);
      return product.ToActionResult(Request.HttpContext);
    }

    // POST api/<ProductsController>
    [HttpPost]
    public void Post([FromBody] string value)
    {
    }

    // PUT api/<ProductsController>/5
    [HttpPut("{id}")]
    public void Put(int id, [FromBody] string value)
    {
    }

    // DELETE api/<ProductsController>/5
    [HttpDelete("{id}")]
    public void Delete(int id)
    {
    }
  }
}
