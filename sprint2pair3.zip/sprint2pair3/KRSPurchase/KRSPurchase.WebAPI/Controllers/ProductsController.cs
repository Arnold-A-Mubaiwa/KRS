﻿using KRSPurchase.ApplicationServices;
using KRSPurchase.Domain;
using KRSPurchase.WebApi.Extensions;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace KRSPurchase.WebAPI.Controllers
{
  [Route("api/[controller]")]
  [ApiController]
  public class ProductsController : ControllerBase
  {
    private readonly ProductsApplicationService _service;

    public ProductsController(ProductsApplicationService service) 
    { 
      _service = service;
    }
    // GET: api/<ProductsController>
    [HttpGet]
    public async Task<IActionResult> Get() 
      => (await _service.ListAll()).ToActionResult(Request.HttpContext);
    

    // GET api/<ProductsController>/{code}
    [HttpGet("{code}")]
    public async Task<IActionResult> Get(string code)
      => (await _service.FindByCode(code)).ToActionResult(Request.HttpContext);
    

    // POST api/<ProductsController>
    [HttpPost]
    public async Task<IActionResult> Post([FromBody] Product product)
      => (await _service.AddAsync(product)).ToActionResult(Request.HttpContext);

    // PUT api/<ProductsController>/5
    [HttpPut("{code}")]
    public async Task<IActionResult> Put(string code, [FromBody] Product product)
      => (await _service.EditAsync(product)).ToActionResult(Request.HttpContext);

    // DELETE api/<ProductsController>/5
    [HttpDelete("{code}")]
    public async Task<IActionResult> Delete(string code)
     => (await _service.DeleteAsync(code)).ToActionResult(Request.HttpContext);
  }
}
