﻿using KRSPurchase.ApplicationServices;
using Microsoft.AspNetCore.Mvc;
using KRSPurchase.WebApi.Extensions;
using KRSPurchase.Domain;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace KRSPurchase.WebAPI.Controllers
{
  
  [Route("api/[controller]")]
  [ApiController]
  public class SuppliersController : ControllerBase
  {
    private readonly SuppliersApplicationServices _service;
    public SuppliersController(SuppliersApplicationServices service)
    {
      _service = service;
    }
    // GET: api/<SuppliersController>
    [HttpGet]
    public async Task<IActionResult> Get()
      => (await _service.ListAll()).ToActionResult(Request.HttpContext);

    // GET api/<SuppliersController>/5
    [HttpGet("{code}")]
    public async Task<IActionResult> Get(string code)
      => (await _service.FindByCode(code)).ToActionResult(Request.HttpContext);

    // POST api/<SuppliersController>
    [HttpPost]
    public async Task<IActionResult> Post([FromBody] Supplier supplier)
    => (await _service.AddAsync(supplier)).ToActionResult(Request.HttpContext);

    // PUT api/<SuppliersController>/5
    [HttpPut("{code}")]
    public async Task<IActionResult> Put(string code, [FromBody] Supplier supplier)
     => (await _service.EditAsync(supplier)).ToActionResult(Request.HttpContext);

    // DELETE api/<SuppliersController>/5
    [HttpDelete("{code}")]
    public async Task<IActionResult> Delete(string code)
      => (await _service.DeleteAsync(code)).ToActionResult(Request.HttpContext);
  }
}
