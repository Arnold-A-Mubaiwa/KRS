﻿using FluentResults;
using KRSPurchase.Domain;
using KRSPurchase.Infrastructure;

namespace KRSPurchase.ApplicationServices
{
  public class PurchaseOrderApplicationService
  {
    private readonly IPurchaseOrdersRepository _purchaseOrderRepository;
    private readonly PurchaseOrderValidator _purchaseOrderValidator = new();
    private readonly ItemValidator _itemValidator = new();

    public PurchaseOrderApplicationService(IPurchaseOrdersRepository poRepository)
    {
      _purchaseOrderRepository = poRepository;
    }

    public async Task<Result<PurchaseOrder>> FindPurchaseOrderAsync(int number)
    { 
      var findPO =  await _purchaseOrderRepository.FindPurchaseOrderAsync(number);
      return Result.Ok(findPO);
    }

    public async Task<Result<bool>> AddPurchaseOrderAsync(PurchaseOrder purchase)
    {
      var validationResult = _purchaseOrderValidator.Validate(purchase);

      if (!validationResult.IsValid)
        return Result.Fail<bool>(validationResult.Errors.Select(e => e.ErrorMessage));

      var addPO = await _purchaseOrderRepository.AddPurchaseOrderAsync(purchase);
      return Result.Ok(addPO);
    }

    public async Task<Result<bool>> AddItemToExistingPurchaseOrderAsync(int number, Item item)
    {
      
      var itemValidationResult = _itemValidator.Validate(item);

      if (!itemValidationResult.IsValid)
        return Result.Fail<bool>(itemValidationResult.Errors.Select(e => e.ErrorMessage));

      var findPurchaseOrder = await _purchaseOrderRepository.FindPurchaseOrderAsync(number);
      findPurchaseOrder.Add(item);
      return Result.Ok<bool>(true);
    }

    public async Task<Result<PurchaseOrder>> CancelPurchaseOrderAsync(int number)
    {
      var existingPurchaseOrder = (await FindPurchaseOrderAsync(number)).Value;

      if (existingPurchaseOrder == null) 
        return Result.Fail<PurchaseOrder>("Purchase Order not found");

      existingPurchaseOrder.Active = false;
      return Result.Ok(existingPurchaseOrder);
    }

    public async Task<Result<List<PurchaseOrder>>> ListPurchaseOrdersAsync()
    {
      var purchaseOrders =  await _purchaseOrderRepository.ListPurchaseOrdersAsync();
      return Result.Ok(purchaseOrders);
    }
  }
}
