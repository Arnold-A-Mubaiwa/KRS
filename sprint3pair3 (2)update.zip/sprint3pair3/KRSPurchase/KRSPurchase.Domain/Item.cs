﻿namespace KRSPurchase.Domain
{
  public class Item
  {
    public Product Product { get; set; }
    public int Quantity { get; set; }
    public decimal Price { get; set; }
    public decimal TotalPrice => Price * Quantity; 
    public Item(Product product, int quantity, decimal price) 
    {
      Product = product;
      Quantity = quantity;
      Price = price;
    }
  }
}
