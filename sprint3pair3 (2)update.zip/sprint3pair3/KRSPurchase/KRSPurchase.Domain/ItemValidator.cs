﻿using FluentValidation;
namespace KRSPurchase.Domain
{
  public class ItemValidator: AbstractValidator<Item>
  {
    public ItemValidator() 
    {
      RuleFor(i => i.Product).SetValidator(new ProductValidator());
      RuleFor(i => i.Quantity).NotEmpty().GreaterThan(0);
      RuleFor(i => i.Price).NotEmpty().GreaterThan(0);
    }
  }
}
