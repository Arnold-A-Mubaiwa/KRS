﻿
namespace KRSPurchase.Domain
{
  public class PODto
  {
    public SupplierDto Supplier { get; set; }
    public DateTime OrderDate { get; init; }
    public DateTime EstimatedDeliveryDate => OrderDate.AddDays(Supplier.LeadTime);
    public PODto() 
    { 
      Supplier= new SupplierDto(new Supplier("SMSNG", "Product", 4));
    }

  }
}
