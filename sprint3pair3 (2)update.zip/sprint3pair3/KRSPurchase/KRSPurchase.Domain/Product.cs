﻿namespace KRSPurchase.Domain
{
  public class Product
  {
    public string Code { get; init; }
    public int ProductId { get; set; }
    public string Name { get; set; }
    public string CreateUser { get; set; }
    public DateTime CreateDate { get; set; }
    public string EditUser { get; set; }
    public DateTime EditDate { get; set; } 

    public Product() {
    
    }

    public Product(string code, string name)
    {
      Code = code;
      Name = name;
    }
  }
}