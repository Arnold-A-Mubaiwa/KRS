﻿namespace KRSPurchase.Domain
{
  public class PurchaseOrder
  {
    public int Number { get; set; } = 1;
    public DateTime OrderDate { get; init; }
    public Supplier Supplier { get; set; }
    public DateTime EstimatedDeliveryDate { get; set; }

    private List<Item> _items  = new List<Item>();
    public IEnumerable<Item> Items => _items;
    public bool Active { get; set; } = true;
    public decimal Total => _items.Sum(i => i.TotalPrice);

    public PurchaseOrder(Supplier supplier, List<Item> startingItems)
    {
      Supplier = supplier;
      OrderDate = DateTime.Now;
      _items = startingItems;
    }

    public PurchaseOrder(PurchaseOrderDto purchaseOrder)
    {
      Supplier = purchaseOrder.Supplier;
      OrderDate = DateTime.Now;
      _items = purchaseOrder.Items;
    }
    public PurchaseOrder()
    { 
    
    }
    public PurchaseOrder(PODto purchaseOrder)
    {
      OrderDate = DateTime.Now;
    }
    public void Add(Item item) 
    {
      _items = GetAddedItems(item, _items);
    }

    private List<Item> GetAddedItems(Item item, List<Item> items)
    {
      var itemInTheList = items.FirstOrDefault(i => i.Product.Code == item.Product.Code);

      if (itemInTheList == null)
        return items.Append(item).ToList();

      return items.Select(i => i.Product.Code == item.Product.Code
        ? new Item(itemInTheList.Product, itemInTheList.Quantity += item.Quantity, itemInTheList.Price)
        : i).ToList();
    }
  }
}
