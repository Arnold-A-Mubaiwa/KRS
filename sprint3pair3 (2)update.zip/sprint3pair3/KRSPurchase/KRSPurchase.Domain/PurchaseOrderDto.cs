﻿namespace KRSPurchase.Domain
{
  public class PurchaseOrderDto
  {
    public Supplier Supplier { get; set; }
    public List<Item> Items { get; set; }
  }
}
