﻿namespace KRSPurchase.Domain
{
  public class Supplier
  {
    public string Code { get; init; }
    public int supplierid { get; set;}
    public string createuser { get; set; }
    public DateTime createdate { get; set; }
    public string edituser { get; set; }
    public DateTime editdate { get; set; }
    public string Name { get; set; }
    public int LeadTime { get; set; }

    public Supplier(string code, string name, int leadTime)
    {
      Code = code;
      Name = name;
      LeadTime = leadTime;
    }
    Supplier() { 
    
    }
  }
}
