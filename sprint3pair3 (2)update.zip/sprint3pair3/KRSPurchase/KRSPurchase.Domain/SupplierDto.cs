﻿namespace KRSPurchase.Domain
{
  public class SupplierDto
  {
    public int SupplierId { get; set; }
    public int LeadTime { get; set; }
    public string Name { get; set; }
    public string Code { get; set; }
    public SupplierDto() { }

    public SupplierDto(Supplier supplier)
    {
      SupplierId = supplier.supplierid;
      Code = supplier.Code;
      Name = supplier.Name;
      LeadTime = supplier.LeadTime;
      
    }
  }
}
