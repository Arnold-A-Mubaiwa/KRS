﻿using KRSPurchase.Domain;

namespace KRSPurchase.Infrastructure
{
  public interface IProductsRepository
  {
    public Task<IList<Product>> ListProductsAsync();
    public Task<Product> FindProductByCodeAsync(string code);
    public Task<Product?> FindProductByIDAsync(int id);
    public Task<int> AddProductAsync(Product product);
    public Task<bool> EditProductAsync(Product product);
    public Task<bool> DeleteProductAsync(int id);
  }
}