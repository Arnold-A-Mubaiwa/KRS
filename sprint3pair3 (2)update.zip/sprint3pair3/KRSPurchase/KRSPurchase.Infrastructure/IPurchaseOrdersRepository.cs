﻿using KRSPurchase.Domain;

namespace KRSPurchase.Infrastructure
{
  public interface IPurchaseOrdersRepository
  {
    public Task<List<PurchaseOrder>> ListPurchaseOrdersAsync();
    public Task<PurchaseOrder> FindPurchaseOrderAsync(int number);
    public Task<bool> AddPurchaseOrderAsync(PurchaseOrder purchase);
    public Task<bool> AddItemToExistingPurchaseOrderAsync(PurchaseOrder purchase, List<Item> items);
    public Task<PurchaseOrder> CancelOrderAsync(int number);
  }
}
