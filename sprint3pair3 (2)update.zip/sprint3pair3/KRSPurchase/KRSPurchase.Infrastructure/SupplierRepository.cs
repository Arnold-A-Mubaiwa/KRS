﻿using Dapper;
using KRSPurchase.Domain;
using System.Data;

namespace KRSPurchase.Infrastructure
{
  public class SupplierRepository : ISuppliersRepository
  {
    private readonly IDbConnection _connection;
    public SupplierRepository(IDbConnection connection) {
      _connection = connection;
    }

    public async Task<int> AddSupplierAsync(Supplier supplier)
    {
      var parameter = new
      {
        code = supplier.Code,
        name = supplier.Name,
        leadtime = supplier.LeadTime,
        user = supplier.createuser,
      };
      var result = await _connection.QueryAsync<int>("suppliers_add", parameter, commandType: CommandType.StoredProcedure);
      return result.SingleOrDefault();
    }

    public async Task<bool> DeleteSupplierAsync(int id )
    {
      var result = await _connection.ExecuteAsync("suppliers_delete", new { id }, commandType: CommandType.StoredProcedure);
      return result == 1;
    }

    public async Task<bool> EditSupplierAsync(Supplier supplier)
    {
      var parameters = new {
        id = supplier.supplierid,
        name = supplier.Name,
        leadtime = supplier.LeadTime,
        editname = supplier.edituser,
      };
      var result = await _connection.ExecuteAsync("suppliers_edit", parameters, commandType: CommandType.StoredProcedure);
      return result == 1;
    }

    public async Task<Supplier> FindSupplierByCodeAsync(string code)
    {
      var parameter = new
      {
        Code = code,
      };
      IEnumerable<Supplier?> suppliers = await _connection.QueryAsync<Supplier>("suppliers_getByCode", parameter, commandType: CommandType.StoredProcedure);
      return suppliers.SingleOrDefault();
    }
    public async Task<Supplier> FindSupplierByIdAsync(int id)
    {
      var parameter = new
      {
        id = id,
      };
      IEnumerable<Supplier?> suppliers = await _connection.QueryAsync<Supplier>("suppliers_getById", parameter, commandType: CommandType.StoredProcedure);
      return suppliers.SingleOrDefault();
    }
    public async Task<IList<Supplier>> ListSuppliersAsync()
    {
      var supplier = await _connection.QueryAsync<Supplier>("suppliers_list", CommandType.StoredProcedure);
      return supplier.ToList();
    }
  }
}
