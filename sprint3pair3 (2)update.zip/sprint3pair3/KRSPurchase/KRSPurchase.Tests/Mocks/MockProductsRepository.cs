﻿using KRSPurchase.Domain;
using KRSPurchase.Infrastructure;

namespace KRSPurchase.Tests.Mocks
{
  public class MockProductsRepository : IProductsRepository
  {
    private List<Product> _products = new()
    {
      new Product("KYBRD", "Keyboard"){ProductId =1},
      new Product("PRJTR", "Projecter"){ ProductId =2},
      new Product("CHAIR", "Chair"){ ProductId =3},
      new Product("F2431", "Laptop") { ProductId = 4 },
    };
    
    public async Task<IList<Product>> ListProductsAsync()
    {
      return _products;
    }

    public async Task<Product?> FindProductByCodeAsync(string code)
    {
      return _products.FirstOrDefault(g => g.Code == code);
    }
    public async Task<Product?> FindProductByIDAsync(int id)
    {
      return _products.FirstOrDefault(g => g.ProductId == id);
    }
    public async Task<int> AddProductAsync(Product product)
    {
      _products.Add(product);
      return product.ProductId;
    }

    public async Task<bool> EditProductAsync(Product product)
    {
      _products = _products
        .Select(g => g.Code == product.Code ? product : g)
        .ToList();
      return true;
    }

    public async Task<bool> DeleteProductAsync(int id)
    {
      var product = await FindProductByIDAsync(id);
      if (product == null) 
        return false;

      _products.Remove(product);
      return true;
    }
  }
}
