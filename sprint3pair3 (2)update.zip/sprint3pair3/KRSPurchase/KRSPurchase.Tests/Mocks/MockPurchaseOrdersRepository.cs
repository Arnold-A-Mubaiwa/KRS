﻿using KRSPurchase.Domain;
using KRSPurchase.Infrastructure;

namespace KRSPurchase.Tests.Mocks
{
  public class MockPurchaseOrdersRepository : IPurchaseOrdersRepository
  {
    private List<PurchaseOrder> _purchaseOrders = new List<PurchaseOrder>()
    {
      new PurchaseOrder ( new Supplier("ABCDA", "Ab", 3), new List<Item>() { new Item(new Product("WEARV", "Wearing Clothe"), 2, 50.52m) }),
    };

    public async Task<PurchaseOrder> FindPurchaseOrderAsync(int number)
    {
      return _purchaseOrders.FirstOrDefault(p => p.Number == number)!;
    }

    public async Task<bool> AddPurchaseOrderAsync(PurchaseOrder purchase)
    {
      purchase.Number = _purchaseOrders.Count + 1;
      _purchaseOrders.Add(purchase);
      return true;
    }

    public async Task<bool> AddItemToExistingPurchaseOrderAsync(PurchaseOrder purchase, List<Item> items)
    {
      items.ForEach(purchase.Add);
      return true;
    }

    public async Task<PurchaseOrder> CancelOrderAsync(int number)
    {
      var existingPurchaseOrder = await FindPurchaseOrderAsync(number);

      if (existingPurchaseOrder == null) 
        return existingPurchaseOrder;

      existingPurchaseOrder.Active = false;
      return existingPurchaseOrder;
    }

    public async Task<List<PurchaseOrder>> ListPurchaseOrdersAsync()
    {
      return _purchaseOrders;
    }
  }
}
