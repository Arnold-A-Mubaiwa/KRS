﻿using KRSPurchase.ApplicationServices;
using KRSPurchase.Domain;
using KRSPurchase.Infrastructure;

namespace KRSPurchase.Tests.Mocks
{
  public class MockSupplierRepository : ISuppliersRepository
  {
    private List<Supplier> _suppliers = new List<Supplier>()
    {
      new Supplier("GTYAR", "Yaris", 2){ supplierid = 1},
      new Supplier("REDDR", "Redragon", 5){ supplierid = 2},
      new Supplier("AGILE", "Scrumscxi", 1){ supplierid = 3},
      new Supplier("GIELS", "Genetics", 2) { supplierid = 4},
    };
    public async Task<Supplier> FindSupplierByCodeAsync(string code)
    {
      return _suppliers.FirstOrDefault(s => s.Code == code)!;
    }
    public async Task<Supplier> FindSupplierByIdAsync(int id)
    {
      return _suppliers.FirstOrDefault(s => s.supplierid == id)!;
    }
    public async Task<IList<Supplier>> ListSuppliersAsync()
    {
      return _suppliers;
    }

    public async Task<int> AddSupplierAsync(Supplier supplier)
    {
      _suppliers.Add(supplier);
      return supplier.supplierid;
    }

    public async Task<bool> DeleteSupplierAsync(int id)
    {
      var supplier = await FindSupplierByIdAsync(id);
      if (supplier == null) return false;
      _suppliers.Remove(supplier);
      return true;
    }

    public async Task<bool> EditSupplierAsync(Supplier supplier)
    { 
      _suppliers = _suppliers
           .Select(s => s.supplierid == supplier.supplierid ? supplier : s)
           .ToList();

      return true;
    }
  }
}
