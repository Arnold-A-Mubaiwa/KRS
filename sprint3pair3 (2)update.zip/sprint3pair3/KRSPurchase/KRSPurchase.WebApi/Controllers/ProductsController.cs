﻿using KRSPurchase.ApplicationServices;
using Microsoft.AspNetCore.Mvc;
using KRSPurchase.WebApi.Extensions;
using KRSPurchase.Domain;
using KRSPurchase.WebApi.Filters;

namespace KRSPurchase.WebApi.Controllers
{
  [Route("api/[controller]")]
  [ApiController]
  public class ProductsController : ControllerBase
  {
    private readonly ProductsApplicationService _service;

    public ProductsController(ProductsApplicationService service)
    {
      _service = service;
    }

    // GET: api/Products
    [HttpGet]
    public async Task<IActionResult> Get()
      => (await _service.ListProductsAsync()).ToActionResult(Request.HttpContext);

    // GET: api/Products/5
    [HttpGet("code/{code}", Name = "Get")]
    public async Task<IActionResult> Get(string code)
      => (await _service.FindProductByCodeAsync(code)).ToActionResult(Request.HttpContext);

    // GET: api/Products/1
    [HttpGet("{id}", Name = "GetId")]
    public async Task<IActionResult> Get(int id)
        => (await _service.FindByProductByIDAsync(id)).ToActionResult(Request.HttpContext);

    // POST: api/Products
    [HttpPost]
    public async Task<IActionResult> Post([FromBody] Product product) {
      product.CreateUser = "Web User";
      product.EditUser = "Web User";
      return (await _service.AddProductAsync(product)).ToActionResult(Request.HttpContext);
    }
    

    // PUT: api/Products/5
    [HttpPut("{id}")]
    [ValidateRoute("id", "ProductId")]
    public async Task<IActionResult> Put(int id, [FromBody] Product product)
    {
      product.EditUser = "Tino";
      return (await _service.EditProductAsync(product)).ToActionResult(Request.HttpContext);
    }
    // DELETE: api/Products/5
    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
      => (await _service.DeleteProductAsync(id)).ToActionResult(Request.HttpContext);
  }
}