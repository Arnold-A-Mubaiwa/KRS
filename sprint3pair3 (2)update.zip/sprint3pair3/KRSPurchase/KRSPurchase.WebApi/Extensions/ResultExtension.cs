﻿using FluentResults;
using Microsoft.AspNetCore.Mvc;

namespace KRSPurchase.WebApi.Extensions;

public static class ResultExtension
{
  public static IActionResult ToActionResult<T>(this Result<T> result, HttpContext context)
  {
    return result switch
    {
      { IsFailed: true } => new BadRequestObjectResult(CreateProblemDetails(result.Errors, context)),
      { IsSuccess: true } => DetermineReturnType(result.Value, context),
      _ => throw new InvalidOperationException("Invalid result state")
    };
  }

  private static IActionResult DetermineReturnType<T>(T resultValue, HttpContext context)
  {
     return context.Request.Method switch
    {
      "GET" => new OkObjectResult(resultValue),
      "POST" => new CreatedResult(context.Request.Path, resultValue),
      "PUT" when resultValue is not null => new OkObjectResult(resultValue),
      "PUT" => new NoContentResult(),
      "PATCH" => new NoContentResult(),
      "DELETE" => new NoContentResult(),
      _ => throw new InvalidOperationException("Invalid HTTP method")
    };
  }

  private static ProblemDetails CreateProblemDetails(IEnumerable<IError> errors, HttpContext context)
  {
    var problemDetails = new ProblemDetails
    {
      Status = StatusCodes.Status400BadRequest,
      Title = "One or more validation errors occurred.",
      Type = "https://tools.ietf.org/html/rfc7231#section-6.5.1",
      Detail = "See the errors property for details.",
      Instance = context.Request.Path
    };

    problemDetails.Extensions.Add("errors", errors.Select(e => e.Message));

    return problemDetails;
  }
}