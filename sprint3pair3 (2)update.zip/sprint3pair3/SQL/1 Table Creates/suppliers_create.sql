use krspurchase
go

if not exists
(
  select 1
  from sys.objects
  where name='supplier' and type='U'
)
begin
create table supplier
(
  supplierid    int             primary key,
  code          nchar(5)        not null,
  name          nvarchar(500)   not null,
  leadtime      int             not null,
  createuser    nvarchar(500)   not null,
  createdate    datetime2       not null,
  edituser      nvarchar(500)   not null,
  editdate      datetime2       not null
)
end
go