use krspurchase
go

drop proc if exists product_add
go

create proc product_add
  (
  @code       nchar(5),
  @name       nvarchar(500),
  @createuser nvarchar(500), 
  @edituser   nvarchar(500)
  )
as 
  declare     @todaydate datetime2 = getdate()
  insert into product
  (
     code,
     name, 
     createuser,
     createdate, 
     edituser, 
     editdate
  )
  values
  (
     @code, 
     @name, 
     @createuser, 
     @todaydate, 
     @edituser, 
     @todaydate
  )
  select @@IDENTITY
  go

  grant execute on product_add to public
  go