use krspurchase
go

drop proc if exists product_delete
go

create proc product_delete
(
 @id int
)
  as 
    delete 
    from   product
    where  productid = @id
go

grant execute on product_delete to public
go