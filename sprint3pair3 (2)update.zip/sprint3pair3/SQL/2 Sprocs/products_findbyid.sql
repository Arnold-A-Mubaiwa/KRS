use krspurchase
go

drop proc if exists product_findbyid 
go 

create proc product_findbyid
(
   @id int
)
as
  select productid,
         code,
         name,
         createuser,
         createdate,
         edituser,
         editdate
  from product

  where productid = @id
  go

  grant execute on product_findbyid to public
  go