use krspurchase
go

drop proc if exists suppliers_getByCode
go

create proc suppliers_getByCode
(
  @code nchar(5)
)
as
  select
      supplierid,
      code,
      name,
      leadtime,
      createuser,
      createdate,
      edituser,
      editdate
  from supplier
  where code = @code
go

grant execute on suppliers_getByCode to public
go