﻿using FluentResults;
using KRSPurchase.Domain;
using KRSPurchase.Infrastructure;
using System.Data.Common;
using System.Data;

namespace KRSPurchase.ApplicationServices
{
  public class ProductsApplicationService
  {
    private readonly IProductsRepository _productsRepository;
    private readonly ProductValidator _productValidator = new();
    public ProductsApplicationService(IProductsRepository repository)
    {
      _productsRepository = repository;
    }

    public async Task<Result<int>> AddProductAsync(Product product)
    {
      var checkDuplicate = await CheckProductDuplicate(product.Code);
      var validationResult = await _productValidator.ValidateAsync(product);

      if (!validationResult.IsValid)
        return Result.Fail<int>(validationResult.Errors.Select(e => e.ErrorMessage));

      if (checkDuplicate)
        return Result.Fail<int>("Duplicate Product");

      var addedCode = await _productsRepository.AddProductAsync(product);
      return Result.Ok(addedCode);
    }

    public async Task<Result<bool>> DeleteProductAsync(int id)
    {
      var existingProduct = await _productsRepository.FindProductByIDAsync(id);

      if (existingProduct == null)
        return Result.Fail<bool>("Product not found");

      return await _productsRepository.DeleteProductAsync(id);
    }

    public async Task<Result<bool>> EditProductAsync(Product product)
    {
      var existingProduct = await _productsRepository.FindProductByCodeAsync(product.Code);
      var validate = _productValidator.Validate(product);

      if (!validate.IsValid) 
        return Result.Fail<bool>(validate.Errors.Select(e => e.ErrorMessage));
      else if (existingProduct == null) 
        return Result.Fail<bool>("Product not found");

      return await _productsRepository.EditProductAsync(product);
    }

    public async Task<Result<IList<Product>>> ListProductsAsync()
    {
      var products = await _productsRepository.ListProductsAsync();
      return Result.Ok(products);
    }

    public async Task<bool> CheckProductDuplicate(string code)
    {
      var product = await _productsRepository.FindProductByCodeAsync(code);
      return (product != null);
    }

    public async Task<Result<Product>> FindProductByCodeAsync(string code)
    {
      var product = await _productsRepository.FindProductByCodeAsync(code);
      return Result.Ok(product);
    }
    public async Task<Result<Product>> FindByProductByIDAsync(int id) {
      var product = await _productsRepository.FindProductByIDAsync(id);
      if (product is null) return Result.Fail<Product>("Product not found");
      
      return Result.Ok(product);
    }
  }
}