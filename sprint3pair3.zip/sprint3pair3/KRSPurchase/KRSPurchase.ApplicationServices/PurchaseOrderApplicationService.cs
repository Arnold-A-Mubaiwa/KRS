﻿using FluentResults;
using KRSPurchase.Domain;
using KRSPurchase.Infrastructure;
using System.Linq;

namespace KRSPurchase.ApplicationServices
{
  public class PurchaseOrderApplicationService
  {
    private readonly IPurchaseOrdersRepository _purchaseOrderRepository;
    private readonly PurchaseOrderValidator _purchaseOrderValidator = new();
    private readonly ItemValidator _itemValidator = new();

    public PurchaseOrderApplicationService(IPurchaseOrdersRepository poRepository)
    {
      _purchaseOrderRepository = poRepository;
    }

    public async Task<Result<PurchaseOrder>> FindPurchaseOrderAsync(int number)
    { 
      var findPO =  await _purchaseOrderRepository.FindPurchaseOrderAsync(number);
      if (findPO == null) return Result.Fail<PurchaseOrder>("Purchase order not found");
      var listofitems = (await _purchaseOrderRepository.ListItems(number)).Select(dto => new Item(dto)).ToList();
      var  purchaseOrders = new PurchaseOrder(findPO, listofitems);
      return Result.Ok(purchaseOrders);
    }
    public async Task<Result<PurchaseOrder>> FindPurchaseOrderByNumber(int number)
    {
      var findPO = await _purchaseOrderRepository.FindPurchaseOrderAsync(number);
      if (findPO == null) return Result.Fail<PurchaseOrder>("Purchase order not found");
      var purchaseOrders = new PurchaseOrder(findPO);
      return Result.Ok(purchaseOrders);
    }

    public async Task<Result<bool>> AddPurchaseOrderAsync(PurchaseOrder purchase)
    {
      var validationResult = _purchaseOrderValidator.Validate(purchase);

      if (!validationResult.IsValid)
        return Result.Fail<bool>(validationResult.Errors.Select(e => e.ErrorMessage));

      var addPO = await _purchaseOrderRepository.AddPurchaseOrderAsync(purchase);
      return Result.Ok(addPO);
    }

    public async Task<Result<bool>> AddItemToExistingPurchaseOrderAsync(int number, Item item)
    {
      
      var itemValidationResult = _itemValidator.Validate(item);

      if (!itemValidationResult.IsValid)
        return Result.Fail<bool>(itemValidationResult.Errors.Select(e => e.ErrorMessage));

      var findPurchaseOrder = await _purchaseOrderRepository.FindPurchaseOrderAsync(number);
      if (findPurchaseOrder == null) return Result.Fail<bool>("Purchase order does not exist");

      await _purchaseOrderRepository.AddItemsToPurchaseOrder(number, item);
      return Result.Ok(true);
    }

    public async Task<Result<bool>> CancelPurchaseOrderAsync(int number)
    {
      var existingPurchaseOrder = await _purchaseOrderRepository.FindPurchaseOrderAsync(number);
      if (existingPurchaseOrder == null) 
        return Result.Fail<bool>("Purchase Order not found");
      var cancelPurchaseOrder = await _purchaseOrderRepository.CancelOrderAsync(number);
    
      return Result.Ok(cancelPurchaseOrder);
    }
    public async Task<Result<IEnumerable<PurchaseOrder>>> ListPurchaseOrderAsync()
    {
      var purchaseOrders = (await _purchaseOrderRepository.ListPurchaseOrderAsync());
     var po = purchaseOrders.Select(purchaseOrders => new PurchaseOrder(purchaseOrders));
      return Result.Ok(po);
    }
  }
}
