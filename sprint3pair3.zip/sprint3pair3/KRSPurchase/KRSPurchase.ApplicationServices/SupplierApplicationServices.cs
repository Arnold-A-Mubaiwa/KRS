﻿using KRSPurchase.Domain;
using FluentResults;
using KRSPurchase.Infrastructure;

namespace KRSPurchase.ApplicationServices
{
  public class SupplierApplicationServices
  {
    private readonly ISuppliersRepository _suppliersRepository;

    private SupplierValidator _supplierValidator = new();
    public SupplierApplicationServices(ISuppliersRepository supplierRepository) 
    {
      _suppliersRepository = supplierRepository;
    }

    public async Task<Result<Supplier>> FindSupplierAsync(string code)
    {
      var supplier = await _suppliersRepository.FindSupplierByCodeAsync(code);
      return Result.Ok(supplier);
    }
    public async Task<Result<Supplier>> FindSupplierByIdAsync(int id)
    {
      var supplier = await _suppliersRepository.FindSupplierByIdAsync(id);
      return Result.Ok(supplier);
    }

    public async Task<Result<int>> AddSupplierAsync(Supplier supplier)
    {
      var checkDuplicate = await CheckDuplicateAsync(supplier.SupplierId);
      var validationResult = await _supplierValidator.ValidateAsync(supplier);

      if (!validationResult.IsValid)
        return Result.Fail<int>(validationResult.Errors.Select(e => e.ErrorMessage));
      if (checkDuplicate)
        return Result.Fail<int>("Duplicate product found");

      var addedCode = await _suppliersRepository.AddSupplierAsync(supplier);
      return Result.Ok(addedCode);
    }

    public async Task<Result<bool>> EditSupplierAsync(Supplier supplier)
    {
      var existingSupplier = await _suppliersRepository.FindSupplierByCodeAsync(supplier.Code);
      var validate = _supplierValidator.Validate(supplier);

      if (!validate.IsValid)
        return Result.Fail<bool>(validate.Errors.Select(e => e.ErrorMessage));
      else if (existingSupplier == null)
        return Result.Fail<bool>("Supplier not found");

      var editedSupplier = await _suppliersRepository.EditSupplierAsync(supplier);
      return Result.Ok(editedSupplier);
    }

    public async Task<Result<bool>> DeleteSupplierAsync(int id)
    {
      var existingSupplier = await _suppliersRepository.FindSupplierByIdAsync(id);
      if (existingSupplier == null)
        return Result.Fail<bool>("Supplier not found");

      var deletedSupplier = await _suppliersRepository.DeleteSupplierAsync(existingSupplier.SupplierId);
      return Result.Ok(deletedSupplier);
    }

    public async Task<Result<IList<Supplier>>> ListSuppliersAsync()
    {
      var suppliers = await _suppliersRepository.ListSuppliersAsync();
      return Result.Ok(suppliers);
    }

    public async Task<bool> CheckDuplicateAsync(int id)
    {
      var checkSupplier = await _suppliersRepository.FindSupplierByIdAsync(id);
      return (checkSupplier != null);
    }
   }
}
