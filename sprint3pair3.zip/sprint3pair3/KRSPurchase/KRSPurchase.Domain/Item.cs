﻿namespace KRSPurchase.Domain
{
  public class Item
  {
    public Product Product { get; set; } = new Product();
    public int Quantity { get; set; }
    public decimal Price { get; set; }
    public decimal TotalPrice => Price * Quantity;
    public string CreateUser { get; set; }
    public DateTime CreateDate { get; set; }
    public string EditUser { get; set; }
    public DateTime EditDate { get; set; }
    public Item(Product product, int quantity, decimal price) 
    {
      Product = product;
      Quantity = quantity;
      Price = price;
    }
    public Item(ItemDto item) 
    {
      Quantity= item.Quantity;
      Price = item.Price;
      CreateUser= item.CreateUser;
      CreateDate= item.CreateDate; 
      EditUser= item.EditUser;
      EditDate= item.EditDate;
      Product.ProductId = item.ProductId;
      Product.Name = item.Name;
      Product.Code  = item.Code;
      Product.CreateDate = item.ProductCreateDate;
      Product.EditDate = item.ProductEditDate;
      Product.CreateUser = item.ProductCreateUser;
      Product.EditUser = item.ProductEditUser;
    }

    public Item() { }
  }
}
