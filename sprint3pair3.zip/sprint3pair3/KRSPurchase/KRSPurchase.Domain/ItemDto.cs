﻿namespace KRSPurchase.Domain
{
  public class ItemDto
  { 
    public int Quantity { get; set; }
    public decimal Price { get; set; }
    public decimal TotalPrice => Price * Quantity;
    public string CreateUser { get; set; }
    public DateTime CreateDate { get; set; }
    public string EditUser { get; set; }
    public DateTime EditDate { get; set; }

    public string Code { get; init; }
    public int ProductId { get; set; }
    public string Name { get; set; }
    public string ProductCreateUser { get; set; }
    public DateTime ProductCreateDate { get; set; }
    public string ProductEditUser { get; set; }
    public DateTime ProductEditDate { get; set; }
    public ItemDto() 
    {
    
    }
  }
}
