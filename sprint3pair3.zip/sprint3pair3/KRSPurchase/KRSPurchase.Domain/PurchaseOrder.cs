﻿namespace KRSPurchase.Domain
{
  public class PurchaseOrder
  {
    public int Number { get; set; } = 1;
    public DateTime OrderDate { get; set; }
    public Supplier Supplier { get; set; } = new Supplier();
    public DateTime EstimatedDeliveryDate => OrderDate.AddDays(Supplier.LeadTime);
    private List<Item> _items  = new List<Item>();
    public IEnumerable<Item> Items => _items;
    public bool Active { get; set; } = true;
    public decimal Total => _items.Sum(i => i.TotalPrice);
    
    public PurchaseOrder(Supplier supplier, List<Item> startingItems)
    {
      Supplier = supplier;
      OrderDate = DateTime.Now;
      _items = startingItems;
    }

    public PurchaseOrder(PurchaseOrderAddDto purchase) 
    {
      OrderDate = DateTime.Now;
      Supplier = purchase.Supplier;
      Supplier.CreateUser = purchase.User;
      _items = purchase.items;
    }
    public PurchaseOrder(PurchaseOrderDto purchaseOrder)
    {
      Supplier = purchaseOrder.Supplier;
      OrderDate = DateTime.Now;
      _items = purchaseOrder.Items;
    }

   
    public PurchaseOrder(SupplierPurchaseOrderDTO purchaseOrder, List<Item> items)
    {
      Number = purchaseOrder.Number;
      OrderDate = purchaseOrder.OrderDate;
      Active = purchaseOrder.Active == 1;
      Supplier.Name= purchaseOrder.Name;
      Supplier.SupplierId = purchaseOrder.SupplierId;
      Supplier.Code = purchaseOrder.Code;
      Supplier.LeadTime = purchaseOrder.LeadTime;
      Supplier.CreateUser = purchaseOrder.createuser;
      Supplier.CreateDate = purchaseOrder.CreateDate;
      Supplier.EditUser = purchaseOrder.Edituser;
      Supplier.EditDate = purchaseOrder.Editdate;
      _items = items;      
    }
    public PurchaseOrder(SupplierPurchaseOrderDTO purchaseOrder)
    {
      Number = purchaseOrder.Number;
      OrderDate = purchaseOrder.OrderDate;
      Active = purchaseOrder.Active == 1;
      Supplier.Name = purchaseOrder.Name;
      Supplier.SupplierId = purchaseOrder.SupplierId;
      Supplier.Code = purchaseOrder.Code;
      Supplier.LeadTime = purchaseOrder.LeadTime;
      Supplier.CreateUser = purchaseOrder.createuser;
      Supplier.CreateDate = purchaseOrder.CreateDate;
      Supplier.EditUser = purchaseOrder.Edituser;
      Supplier.EditDate = purchaseOrder.Editdate;
    }

    public void Add(Item item) 
    {
      _items = GetAddedItems(item, _items);
    }

    private List<Item> GetAddedItems(Item item, List<Item> items)
    {
      var itemInTheList = items.FirstOrDefault(i => i.Product.Code == item.Product.Code);

      if (itemInTheList == null)
        return items.Append(item).ToList();

      return items.Select(i => i.Product.Code == item.Product.Code
        ? new Item(itemInTheList.Product, itemInTheList.Quantity += item.Quantity, itemInTheList.Price)
        : i).ToList();
    }
    public PurchaseOrder() { }
  }
}
