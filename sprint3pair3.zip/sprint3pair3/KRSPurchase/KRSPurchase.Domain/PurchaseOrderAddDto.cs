﻿namespace KRSPurchase.Domain
{
  public class PurchaseOrderAddDto
  {
    public Supplier Supplier { get; set; }

    public string User { get;set; }
    public List<Item> items { get; set; }
  }
}
