﻿namespace KRSPurchase.Domain
{
  public class Supplier
  {
    public string Code { get; set; }
    public int SupplierId { get; set;}
    public string CreateUser { get; set; }
    public DateTime CreateDate { get; set; }
    public string EditUser { get; set; }
    public DateTime EditDate { get; set; }
    public string Name { get; set; }
    public int LeadTime { get; set; }

    public Supplier(string code, string name, int leadTime)
    {
      Code = code;
      Name = name;
      LeadTime = leadTime;
    }
    public Supplier() { 
    
    }
  }
}
