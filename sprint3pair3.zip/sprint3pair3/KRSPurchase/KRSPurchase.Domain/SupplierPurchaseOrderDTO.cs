﻿
using System.Data;

namespace KRSPurchase.Domain
{
  public class SupplierPurchaseOrderDTO
  {
    public int Number { get; set; }
    public DateTime OrderDate { get; init; }
    public int SupplierId { get; set; }
    public string Name { get; set; }
    public string Code { get; set; }
    public int LeadTime { get; set; }
    public int Active { get; set; }
    public DateTime CreateDate { get; set; }
    public DateTime EstimatedDeliveryDate => OrderDate.AddDays(LeadTime);

    public string createuser { get; set; }
    public string Edituser { get; set; }
    public DateTime Editdate { get; set; }

    private List<Item> _items = new List<Item>();
    public IEnumerable<Item> Items => _items;
    public string ProductCode { get; set; }

    //
    public int Quantity { get; set; }
    public decimal Price { get; set; }
    public decimal TotalPrice => Price * Quantity;

    /*public string ItemsCreateUser { get; set; }
    public DateTime ItemsCreateDate { get; set; }
    public string ItemsEditUser { get; set; }
    public DateTime ItemsEditDate { get; set; }*/
    public void Add(Item item)
    {
      _items = GetAddedItems(item, _items);
    }

    private List<Item> GetAddedItems(Item item, List<Item> items)
    {
      var itemInTheList = items.FirstOrDefault(i => i.Product.Code == item.Product.Code);

      if (itemInTheList == null)
        return items.Append(item).ToList();

      return items.Select(i => i.Product.Code == item.Product.Code
        ? new Item(itemInTheList.Product, itemInTheList.Quantity += item.Quantity, itemInTheList.Price)
        : i).ToList();
    }

    public SupplierPurchaseOrderDTO(int number, DateTime orderDate, int supplierId, string name, string code, int leadTime, int active, DateTime createDate, string createuser, string edituser, DateTime editdate, List<Item> items)
    {
      Number = number;
      OrderDate = orderDate;
      SupplierId = supplierId;
      Name = name;
      Code = code;
      LeadTime = leadTime;
      Active = active;
      CreateDate = createDate;
      this.createuser = createuser;
      Edituser = edituser;
      Editdate = editdate;
      _items = items;
    }
    public SupplierPurchaseOrderDTO() { }
  }
}