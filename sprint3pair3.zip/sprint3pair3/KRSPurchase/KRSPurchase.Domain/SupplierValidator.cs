﻿using FluentValidation;

namespace KRSPurchase.Domain
{
  public class SupplierValidator : AbstractValidator<Supplier>
  {
    public SupplierValidator() 
    {
      RuleFor(s => s.Code).NotNull().NotEmpty().MaximumLength(5).MinimumLength(5);
      RuleFor(s => s.Name).NotNull().NotEmpty();
      RuleFor(s => s.LeadTime).GreaterThan(0);
    }
  }
}
