﻿using FluentResults;
using KRSPurchase.Domain;

namespace KRSPurchase.Infrastructure
{
  public interface IPurchaseOrdersRepository
  {
    public Task<SupplierPurchaseOrderDTO> FindPurchaseOrderAsync(int number);
    public Task<PurchaseOrder> FindPurchaseOrderByNumber(int number); 
    public Task<bool> AddPurchaseOrderAsync(PurchaseOrder purchase);
    public Task<bool> CancelOrderAsync(int number);
    public Task<List<SupplierPurchaseOrderDTO>> ListPurchaseOrderAsync();
    public  Task<bool> AddItemsToPurchaseOrder(int number, Item item);
    public Task<List<ItemDto>> ListItems(int id);

  }
}
