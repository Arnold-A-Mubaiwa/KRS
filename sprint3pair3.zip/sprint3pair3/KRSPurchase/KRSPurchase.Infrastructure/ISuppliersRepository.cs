﻿using KRSPurchase.Domain;

namespace KRSPurchase.Infrastructure
{
  public interface ISuppliersRepository
  {
    public Task<IList<Supplier>> ListSuppliersAsync();
    public Task<Supplier> FindSupplierByCodeAsync(string code);
    public Task<Supplier> FindSupplierByIdAsync(int id);
    public Task<int> AddSupplierAsync(Supplier supplier);
    public Task<bool> EditSupplierAsync(Supplier supplier);
    public Task<bool> DeleteSupplierAsync(int id);
  }
}
