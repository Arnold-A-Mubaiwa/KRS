﻿using KRSPurchase.Infrastructure;
using KRSPurchase.Domain;
using System.Data;
using Dapper;

namespace KRSPurchase.Infrastructure
{
  
  public class ProductRepository : IProductsRepository
  {
   
    private readonly IDbConnection _connection;

    public ProductRepository(IDbConnection connection)
    {
      _connection = connection;
    }

    public async Task<int> AddProductAsync(Product product)
    {
      var parameters = new
      {
        code = product.Code,
        name = product.Name,
        createuser = product.CreateUser,
        edituser = product.EditUser,

      };
      var result = await _connection.QueryAsync<int>("products_add", parameters, commandType: CommandType.StoredProcedure);
      return result.SingleOrDefault();
    }

    public async Task<bool> DeleteProductAsync(int id)
    {
      var result = await _connection.ExecuteAsync("products_delete", new { id }, commandType: CommandType.StoredProcedure);
      return result == 1;
    }

    public async Task<bool> EditProductAsync(Product product)
    {
      var parameters = new
      {
        id = product.ProductId,
        name = product.Name,
        edituser = product.EditUser,
      };
      var result = await _connection.ExecuteAsync("products_edit", parameters, commandType: CommandType.StoredProcedure);
      return result == 1;
    }

    public async Task<Product> FindProductByCodeAsync(string code)
    {
      IEnumerable<Product?> products = await _connection.QueryAsync<Product>("products_findbyCode", new { code }, commandType: CommandType.StoredProcedure);
      return products.FirstOrDefault();
    }

    public async Task <Product?> FindProductByIDAsync(int id) {
      IEnumerable<Product?> products =
         await _connection.QueryAsync<Product>("products_findbyid", new { id }, commandType: CommandType.StoredProcedure);
      return products.FirstOrDefault();
    }
    public async Task<IList<Product>> ListProductsAsync()
    {
      var products = await _connection.QueryAsync<Product>("products_list", commandType: CommandType.StoredProcedure);
      return products.ToList();
    }
  }
}
