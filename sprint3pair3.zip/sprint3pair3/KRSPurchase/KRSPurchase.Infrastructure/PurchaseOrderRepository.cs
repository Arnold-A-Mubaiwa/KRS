﻿using Dapper;
using KRSPurchase.Domain;
using System.Data;

namespace KRSPurchase.Infrastructure
{
  public class PurchaseOrderRepository : IPurchaseOrdersRepository
  {
    private readonly IDbConnection _connection;
    public PurchaseOrderRepository(IDbConnection connection) { 
    _connection= connection;
    }

    public async Task<bool> AddItemsToPurchaseOrder(int number,  Item item)
    {
      var parameters = new {
      productid = item.Product.ProductId,
      purchaseorderno = number,
      quantity = item.Quantity,
      price = item.Price,
      user = item.CreateUser,
      
      };
      var result = await _connection.QueryAsync<bool>("item_add",parameters,commandType:CommandType.StoredProcedure);
      return result.SingleOrDefault();
    }

 
    public async Task<bool> AddPurchaseOrderAsync(PurchaseOrder purchase)
    {
      var parameters = new
      {
        supplierid = purchase.Supplier.SupplierId,
        user = purchase.Supplier.CreateUser
      };
      var result = await _connection.QueryAsync<bool>("purchaseorder_add",parameters, commandType: CommandType.StoredProcedure);

      return result.SingleOrDefault();
    }

    public async Task<bool> CancelOrderAsync(int number)
    {
      var parameters = new
      {
        id = number,
        cancel = 0
      };

      var result = await _connection.ExecuteAsync("purchaseorder_cancel", parameters, commandType: CommandType.StoredProcedure);
      return result == 1;
    }

    public async Task<SupplierPurchaseOrderDTO> FindPurchaseOrderAsync(int number)
    {
      var parameter = new {
       id = number
      };
      var result = await _connection.QueryAsync<SupplierPurchaseOrderDTO>("purchaseorder_getByNo",parameter,commandType:CommandType.StoredProcedure);
      return result.SingleOrDefault();
    }
    public async Task<List<SupplierPurchaseOrderDTO>> ListPurchaseOrderAsync()
    {
      var result = await _connection.QueryAsync<SupplierPurchaseOrderDTO>("purchaseorder_listAll", commandType: CommandType.StoredProcedure);
      return result.ToList();
    }
    public async Task<List<ItemDto>> ListItems(int id)
    {
      var result = await _connection.QueryAsync<ItemDto>("item_find", new { id }, commandType: CommandType.StoredProcedure);
      return result.ToList();
    }
    public async Task<Product?> FindProductByIDAsync(int purchaseorderno)
    {
      IEnumerable<Product?> product =
         await _connection.QueryAsync<Product>("listproduct", new { purchaseorderno}, commandType: CommandType.StoredProcedure);
      return product.FirstOrDefault();
    }
    public Task<PurchaseOrder> FindPurchaseOrderByNumber(int number)
    {
      throw new NotImplementedException();
    }
  }
}
