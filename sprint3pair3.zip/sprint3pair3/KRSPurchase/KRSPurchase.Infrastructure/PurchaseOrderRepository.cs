﻿using Dapper;
using KRSPurchase.Domain;
using System.Data;

namespace KRSPurchase.Infrastructure
{
  public class PurchaseOrderRepository : IPurchaseOrdersRepository
  {
    private readonly IDbConnection _connection;
    public PurchaseOrderRepository(IDbConnection connection) { 
    _connection= connection;
    }

    public Task<bool> AddItemToExistingPurchaseOrderAsync(PurchaseOrder purchase, List<Item> items)
    {
      throw new NotImplementedException();
    }

    public Task<bool> AddPurchaseOrderAsync(PurchaseOrder purchase)
    {
      throw new NotImplementedException();
    }

    public Task<PurchaseOrder> CancelOrderAsync(int number)
    {
      throw new NotImplementedException();
    }

    public Task<PurchaseOrder> FindPurchaseOrderAsync(int number)
    {
      throw new NotImplementedException();
    }

    public async Task<List<PurchaseOrder>> ListPurchaseOrdersAsync()
    {
      var result = await _connection.QueryAsync<PurchaseOrder>("purchaseorder_listAll", commandType: CommandType.StoredProcedure);
      return result.ToList();
    }
  }
}
