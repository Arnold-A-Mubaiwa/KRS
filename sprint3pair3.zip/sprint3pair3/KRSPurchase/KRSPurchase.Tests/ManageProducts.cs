using FluentResults;
using KRSPurchase.ApplicationServices;
using KRSPurchase.Domain;
using KRSPurchase.Tests.Mocks;

namespace KRSPurchase.Tests
{
  public class ManageProducts
  {
    private readonly ProductsApplicationService _service = new(new MockProductsRepository());
    private readonly ProductValidator _validator = new();

    [Fact]
    public void ShouldCreateProduct()
    {
      //Given product name = "DELL" and code = "VPROM" 
      var name = "DELL";
      var code = "VPROM";

      //When create product 
      var product = new Product(code, name);

      //Then product should exist
      Assert.NotNull(product);
      Assert.Equal(name, product.Name);
      Assert.Equal(product.Code, code);
    }

    [Fact]
    public async Task ShouldAddProduct()
    {
      //Give Product name="BOTTLE" code="BOT22"
      var product = new Product("BOT22", "BOTTLE");
      //When  Product is Added to the application Service
      var (isSuccess, isFailed, productCode, errors) = await _service.AddProductAsync(product);
      //var addedProduct = (await _service.FindProductByCodeAsync(productCode)).Value;

      //Then the product exists
      Assert.True(isSuccess);
      Assert.False(isFailed);
      //Assert.NotNull(addedProduct);
      Assert.Null(errors);
      //Assert.Equal("BOT22", addedProduct.Code);
    }

    [Fact]
    public async Task ShouldFailToAddProductByCode()
    {
      //Give Product name="BOTTLE" code="BOT22"
      var product = new Product("BOT2", "BOTTLE");

      //When  Product is Added to the application Service
      var addedProduct = await _service.AddProductAsync(product);

      var (isSuccess, isFailed, productCode, errors) = await _service.FindProductByCodeAsync(product.Code);

      //Then the product exists
      Assert.True(addedProduct.IsFailed);
      Assert.True(isSuccess);
      Assert.False(isFailed);
      Assert.Null(productCode);
      Assert.Null(errors);
    }

    [Fact]
    public async Task ShouldFindProductByCode()
    {
      //Given Product by code = "CHAIR"
      var code = "CHAIR";

      //WHEN we find code
      var (isSuccess, isFailed, product, errors) = await _service.FindProductByCodeAsync(code);

      //Then the product exists
      Assert.NotNull(product);
      Assert.True(isSuccess);
      Assert.False(isFailed);
      Assert.Null(errors);
      Assert.Equal(code, product.Code);
    }
    [Fact]
    public async Task ShouldFindProductByid()
    {
      //Given Product by code = "CHAIR"
      var ID = 1;

      //WHEN we find code
      var (isSuccess, isFailed, product, errors) =  await _service.FindByProductByIDAsync(ID);

      //Then the product exists
      //Then the product exists
      Assert.NotNull(product);
      Assert.True(isSuccess);
      Assert.False(isFailed);
      Assert.Null(errors);
      Assert.Equal(ID, product.ProductId);

    }

    [Fact]
    public void ShouldValidateValidProduct()
    {
      // Given product with name = "MARKER" and code = "PMERK"
      var product = new Product("PMERK", "MARKER");
      
      // When we validate the product 
      var validate = _validator.Validate(product);
      
      //Then the product is valid
      Assert.True(validate.IsValid);
    }

    [Fact]
    public void ShouldValidateInvalideProduct()
    {
      // Given invalid product with code = "PMEK" and name = ""
      var product = new Product("PMEK", "");
      
      // When we validate the product 
      var validate = _validator.Validate(product);
      
      //Then the product is inValid
      Assert.False(validate.IsValid);
    }

    [Fact]
    public async Task ShouldDeleteProduct()
    {
      // Given an existing product with code = "F2431"
      var id = 2;

      // When deleting the product
      var (isSuccess, isFailed, productDeleted, errors) = await _service.DeleteProductAsync(id);

      // Then the product should be deleted
      Assert.True(isSuccess);
      Assert.False(isFailed);
      Assert.Null(errors);
      var (isSuccess_, isFailed_, findDeletedProduct,errors_) = await _service.FindByProductByIDAsync(id);
      Assert.True(productDeleted);
      Assert.False(isSuccess_);
      Assert.True(isFailed_);
      Assert.Null(findDeletedProduct);
    }

    [Fact]
    public async Task ShouldFailToDeleteProductByID()
    {
      // Given an non existing product with code = "WHERE"
      var id = 5;

      // When deleting the product
      var(isSuccess, isFailed, deleteProduct, errors) = await _service.DeleteProductAsync(id);

      // Then the product should be not be deleted
      Assert.False(deleteProduct);
      Assert.False(isSuccess);
      Assert.True(isFailed);
      Assert.NotNull(errors);
    }

    [Fact]
    public async Task ShouldEditProduct()
    {
      // Given the code = "PRJTR", name = "Projecter" of an existing Product
      var code = "PRJTR";
      var name = "Projectors";
      var existingProduct = (await _service.FindProductByCodeAsync(code)).Value;

      // When editing the product
      existingProduct.Name = name;
      var (isSuccess, isFailed, newProduct, errors) = await _service.EditProductAsync(existingProduct);
      var edittedProduct = (await _service.FindProductByCodeAsync(code)).Value;

      //Then the product should be edited
      Assert.True(isSuccess);
      Assert.False(isFailed);
      Assert.True(newProduct);
      Assert.Null(errors);
      Assert.Equal(name, edittedProduct.Name);
    }

    [Fact]
    public async Task ShouldFailToEditProductByCode()
    {
      // Given an non existing product with code = "WHER"
      var product = new Product("WHER","Wheres");
      var findProduct = await _service.FindProductByCodeAsync(product.Code);

      // When deleting the product
      var editProduct = await _service.EditProductAsync(product);
      var (isSuccess, isFailed, productFound, errors) = await _service.FindProductByCodeAsync(product.Code);

      // Then the product should be not be deleted
      Assert.True(editProduct.IsFailed);
      Assert.True(isSuccess);
      Assert.False(isFailed);
      Assert.Null(errors);
      Assert.Null(productFound);
    }

    [Fact]
    public async Task ShouldFailToEditProductIfNull()
    {
      // Given an non existing product with code = "WHER"
      var product = new Product("WHERE", "Wheres");
      var findProduct = await _service.FindProductByCodeAsync(product.Code);

      // When deleting the product
      var editProduct = await _service.EditProductAsync(product);
      var (isSuccess, isFailed, productFound, errors) = await _service.FindProductByCodeAsync(product.Code);

      // Then the product should be not be deleted
      Assert.True(editProduct.IsFailed);
      Assert.True(isSuccess);
      Assert.False(isFailed);
      Assert.Null(errors);
      Assert.Null(productFound);
    }

    [Fact]
    public async Task ShouldListProduct()
    {
      // Given an Application Service with at least 1 product
      var existingProductCode = "KYBRD";
      // When listing the products
      var listResult = await _service.ListProductsAsync();
      // Then the AS should have at least 1 product
      Assert.Contains(listResult.Value, g => g.Code == existingProductCode);
      Assert.True(listResult.IsSuccess);
      Assert.True(listResult.Value.Count > 1);
    }

    [Fact]
    public async Task ShouldCheckDuplicate()
    {
      // Given the code of a product
      var code = "PRJTR";
      
      // When the product has duplicate
      var productExist = await _service.CheckProductDuplicate(code);
      
      // Then the duplicate should exist
      Assert.True(productExist);
    }

    [Fact]
    public async Task ShouldFailAdd()
    {
      // Given the product
      var product = new Product("PRJTR", "BOTTLE2");
      
      // When the product has duplicate
      var (isSuccess, isFalied, addProduct, errors) = await _service.AddProductAsync(product);
      
      // Then the product shouldn't be added
      Assert.False(isSuccess);
      Assert.True(isFalied);
      Assert.NotEmpty(errors);
      Assert.Equal(0, addProduct);
    }

    [Fact]
    public async Task ShouldFailToDeleteProductByCodeMock()
    {
      // Given a non existing product with code = "WHERE"
      var id = 5;

      // When deleting the product
      var mock = new MockProductsRepository();
      var delete = await mock.DeleteProductAsync(id);

      // Then the product should not be deleted
      var findDeletedProduct = await mock.FindProductByIDAsync(id);
      Assert.False(delete);
      Assert.Null(findDeletedProduct);
    }


    [Fact]
    public async Task ShouldFailToEditProductByCodeMock()
    {
      // Given an non existing product with code = "WHERE"
      var product = new Product("WHERE", "wheres");

      // When editing the product
      var mock = new MockProductsRepository();
      var editProduct = await mock.EditProductAsync(product);

      // Then the product should not be edited
      var findProduct = await mock.FindProductByCodeAsync(product.Code);
      Assert.True(editProduct);
      Assert.Null(findProduct);
    }
}
}