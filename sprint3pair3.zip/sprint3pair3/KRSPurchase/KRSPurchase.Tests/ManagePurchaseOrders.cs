﻿using System.Security.Cryptography;
using KRSPurchase.ApplicationServices;
using KRSPurchase.Domain;
using KRSPurchase.Tests.Mocks;

namespace KRSPurchase.Tests
{
  public class ManagePurchaseOrders
  {
    private readonly PurchaseOrderValidator _validator = new();
    private readonly ItemValidator _itemValidator = new();
    private readonly PurchaseOrderApplicationService _service = new(new MockPurchaseOrdersRepository());

    [Fact]
    public void ShouldCreateItem()
    {
      // Given a Product("BNNA1", "Banana"), Quantity = 1, and Price = 50
      var product = new Product("BNNA1", "Banana");
      var quantity = 1;
      var price = 50;
      
      // When the Item is created
      var item = new Item(product, quantity, price);
      
      // Then the item should exist
      Assert.NotNull(item);
      Assert.Equal(quantity, item.Quantity);
      Assert.Equal(price, item.Price);
    }

    [Fact]
    public void ShouldCreatePurchaseOrder()
    {
      // Given a number = 1215 and Supplier("BCDSA", "PEN", 2)
      var supplier = new Supplier("BCDSA", "PEN", 2);
      var item1 = new Item(new Product("CRKOO", "Cookie"), 2, 5);
      var item2 = new Item(new Product("ZRKOU", "Zoo Keeper"), 1, 6);
      
      // When the purchase order is created
      var purchaseOrder = new PurchaseOrder(supplier,new List<Item> { item1, item2});
      TimeSpan calculatedLeadTime = purchaseOrder.EstimatedDeliveryDate - purchaseOrder.OrderDate;
      
      // Then it should exist
      Assert.NotNull(purchaseOrder);
      Assert.Equal(supplier, purchaseOrder.Supplier);
      Assert.Equal(2, purchaseOrder.Items.Count());
      Assert.Equal(calculatedLeadTime.Days, supplier.LeadTime);
    }

    [Fact]
    public void ShouldValidatePurchaseOrder()
    {
      // Given the number, supplier, and item list
      var supplier = new Supplier("ABCDA", "Ab", 3);
      var product = new Product("WEARV", "Wearing Clothe");
      var item = new Item(product, 2, 50.52m);
      
      // When validating
      var purchaseOrder = new PurchaseOrder(supplier, new List<Item> { item });
      purchaseOrder.Add(item);

      var validate = _validator.Validate(purchaseOrder);
      // Then it should validate
      Assert.True(validate.IsValid);
    }

    [Fact]
    public void ShouldValidateItem()
    {
      var product = new Product("HAIR1", "Hair cuts");
      var item = new Item(product, 3, 50.30m);
      var validate = _itemValidator.Validate(item);
      Assert.True(validate.IsValid);
    }

    [Fact]
    public void ShouldNotValidateInvalidItem()
    {
      var product = new Product("HAIR", "Hair cuts");
      var item = new Item(product, 3, 50.30m);
      var validate = _itemValidator.Validate(item);
      Assert.False(validate.IsValid);
    }

    [Fact]
    public void ShouldNotValidateInvalidPurchaseOrder2()
    {
      // Given the number, supplier, and item list...giving inValid number=0
      // and inValid item Quantity = 0
      var supplier = new Supplier("ABCDA", "Ab", 3);
      var product = new Product("WEARV", "Wearing Clothe");
      var item = new Item(product, 0, 50.52m);
      
      // When validating
      var purchaseOrder = new PurchaseOrder( supplier, new List<Item> { item});
      purchaseOrder.Add(item);

      var validate = _validator.Validate(purchaseOrder);
      // Then it should validate
      Assert.False(validate.IsValid);
    }

    [Fact]
    public async Task ShouldFindPurchaseOrderByNumber()
    {
      // Given an existing number of purchase order by number=112
      var number = 1;

      // When looking for the purchase order in the appliation server
      var purchaseOrder = (await _service.FindPurchaseOrderAsync(number)).Value;

      // Then the purchase order should exist in the application service
      Assert.NotNull(purchaseOrder);
      Assert.Equal(number, purchaseOrder.Number);
    }

    [Fact]
    public async Task ShouldNotFindPurchaseOrderByNumber()
    {
      // Given an number of a non-existing purchase order by number=112
      var number = 2;

      // When looking for the purchase order in the appliation server
      var purchaseOrder = (await _service.FindPurchaseOrderAsync(number)).Value;

      // Then the purchase order should not exist in the application service
      Assert.Null(purchaseOrder);
    }

    [Fact]
    public async Task ShouldAddPurchaseOrder()
    {
      //Give the  supplier, list of items
      var supplier = new Supplier("ABCDA", "Ab", 3);
      var product = new Product("WEARV", "Wearing Clothe");
      var item = new Item(product, 2, 50.52m);

      // When validating
      var purchaseOrder = new PurchaseOrder( supplier, new List<Item> { item });
      // When adding to the purchase order
      var addToPurchases = await _service.AddPurchaseOrderAsync(purchaseOrder);

      //Then the purchase order should exist
      Assert.True(addToPurchases.IsSuccess);
      var find = (await _service.FindPurchaseOrderAsync(purchaseOrder.Number)).Value;
      Assert.NotNull(find);
      Assert.Equal(purchaseOrder.Number, find.Number);
    }
    [Fact]
    public async Task ShouldFailToAddPurchaseOrder()
    {
      //Given the  supplier and list of items
      var supplier = new Supplier("ABCA", "Ab", 3);
      var product = new Product("WEARV", "Wearing Clothe");
      var item = new Item(product, 2, 50.52m);

      // When validating
      // and adding the purchase order
      var purchaseOrder = new PurchaseOrder(supplier, new List<Item> { item });
      var (isSuccess, isFailed, addToPurchases, errors) = await _service.AddPurchaseOrderAsync(purchaseOrder);

      //Then the purchase order should exist
      var find = (await _service.FindPurchaseOrderAsync(purchaseOrder.Number)).Value;
      Assert.False(isSuccess);
      Assert.True(isFailed);
      Assert.False(addToPurchases);
      Assert.NotNull(errors);
      Assert.NotNull(find);
      Assert.Equal(purchaseOrder.Number, find.Number);
    }

    [Fact]
    public async Task ShouldAddItemsToExistingPurchaseOrder()
    {
      // Given the purchase order number=112 and list of items [Item(), Item()]
      var number = 1;
      var item1 = new Item(new Product("WEARV", "Wearing Clothe"), 2, 50.52m);

      // When added to the purchase order
      var existingPurchaseOrder = (await _service.FindPurchaseOrderAsync(number)).Value;
      var (isSuccess, isFailed , addedPurchase, errors) = await _service.AddItemToExistingPurchaseOrderAsync(existingPurchaseOrder.Number, item1);

      // Then the purchase order should have the added items
      Assert.True(isSuccess);
      Assert.False(isFailed);
      Assert.True(addedPurchase);
      Assert.Null(errors);
    }

    [Fact]
    public async Task ShouldFailToAddItemsToExistingPurchaseOrder()
    {
      // Given the purchase order number=112 and list of items [Item(), Item()]
      var number = 1;
      var item1 = new Item(new Product("WARV", "Wearing Clothe"), 2, 50.52m);

      // When try to add the items to the purchase order
      var existingPurchaseOrder = (await _service.FindPurchaseOrderAsync(number)).Value;
      var (isSuccess, isFailed, addedPurchase, errors) = await _service.AddItemToExistingPurchaseOrderAsync(existingPurchaseOrder.Number, item1);

      // Then the purchase order should not have the added items
      Assert.False(isSuccess);
      Assert.True(isFailed);
      Assert.False(addedPurchase);
      Assert.NotNull(errors);
    }

    [Fact]
    public void ShouldAddQuantityOfSimilarItems() 
    {
      // Given a supplier, items with similar product
      var supplier = new Supplier("BCDSA", "PEN", 2);
      var item1 = new Item(new Product("POPOT", "Cookie"), 2, 5);
      var item2 = new Item(new Product("POPOT", "Cookie"), 1, 6);
      var item3 = new Item(new Product("POPOT", "Cookie"), 3, 5);
      var item4 = new Item(new Product("HUTUI", "Cookie"), 1, 6);
      
      // When the purchase order is created, and items added to the purchase order
      var purchaseOrder = new PurchaseOrder(supplier, new List<Item> { item1 });
      purchaseOrder.Add(item2);
      purchaseOrder.Add(item3);
      purchaseOrder.Add(item4);
      
      // Then the purchase order ITEMS Quantity should increase by number of quantity provided 
      Assert.True(purchaseOrder.Items.Count() == 2);
      Assert.Equal(6, purchaseOrder.Items.ElementAt(0).Quantity);
    }

    [Fact]
    public async Task ShouldCancelPurchaseOrder()
    {
      // Given the purchase order number
      var number = 1;
      var existingPurchaseOrder = (await _service.FindPurchaseOrderAsync(number)).Value;
      Assert.True(existingPurchaseOrder.Active);

      // When canceling the purchase order in the application service
      var (isSuccess, isFailed, cancelPurchaseOrder, errors) = await _service.CancelPurchaseOrderAsync(number);

      // Then the purchase order should not exist on the application service
      Assert.True(isSuccess);
      Assert.False(isFailed);
      Assert.NotNull(cancelPurchaseOrder);
      Assert.Null(errors);
      var cancelledPurchaseOrder = (await _service.FindPurchaseOrderAsync(number)).Value;
      Assert.False(cancelledPurchaseOrder.Active);
    }

    [Fact]
    public async Task ShouldFailToCancelPurchaseOrder()
    {
      // Given the purchase order number
      var number = 0;
      var existingPurchaseOrder = (await _service.FindPurchaseOrderAsync(number)).Value;

      // When we try to cancel the purchase order in the application service
      var (isSuccess, isFailed, cancelPurchaseOrder, errors) = await _service.CancelPurchaseOrderAsync(number);

      // Then the purchase order should not be canceled in the application service
      Assert.False(isSuccess);
      Assert.True(isFailed);
      Assert.Null(cancelPurchaseOrder);
      Assert.NotNull(errors);
      Assert.Null(existingPurchaseOrder);
    }

    [Fact]
    public async Task ShouldListPurchaseOrder()
    {
      // Given Application Service with at least 1 item
      var number = 1;

      // When fetch the purchase order list from the AS
      var purchaseOrders = await _service.ListPurchaseOrdersAsync();

      //Then purchase order should at leaset have 1 item
      Assert.Contains(purchaseOrders.Value, p => p.Number == number);
      Assert.True(purchaseOrders.IsSuccess);
      Assert.True(purchaseOrders.Value.Count > 0);
    }

    [Fact]
    public void ShouldGetTheTotalCostOfItemsOfPurchaseOrder()
    {
      // Given a purchase order with 2 items ..
      var supplier = new Supplier("MRCHA", "Mechanical Keyboard Supplier", 2);
      var item1 = new Item(new Product("LGTE2", "Logic 200"), 4, 800.00m);
      var item2 = new Item(new Product("CRS15", "Corsair K57 RGB"), 1, 1499.99m);
      
      // When the purchase order is created, and item1 initially passed and item2 manually added
      var purchaseOrder = new PurchaseOrder(supplier, new List<Item> { item1 });
      purchaseOrder.Add(item2);
      
      // Then the purchase order should have the total cost of the items added
      var expectedTotalCost = (800.00m * 4) + 1499.99m;
      Assert.Equal(expectedTotalCost, purchaseOrder.Total);
    }

    [Fact]
    public async Task ShouldFailToCancelPurchaseOrderMockRepo()
    {
      // given a mock repo
      var mock = new MockPurchaseOrdersRepository();

      // when we try to cancel a purchase order that does not exist
      var cancelPO = await  mock.CancelOrderAsync(2);

      // then it should fail
      Assert.Null(cancelPO);
    }

    [Fact]
    public async Task ShouldCancelPurchaseOrderMock()
    {
      var mock = new MockPurchaseOrdersRepository();

      var cancelPurchaseOrder = await mock.CancelOrderAsync(1);

      Assert.NotNull(cancelPurchaseOrder);
      Assert.False(cancelPurchaseOrder.Active);
    }

    [Fact]
    public async Task ShouldAddItemToExistingPurchaseOrderMock()
    {
      //given a mock repository
      var mock = new MockPurchaseOrdersRepository();


      //when we add an item(s) to an existing purchase order
      var item1 = new Item(new Product("PLMKI", "Biscuit"), 2, 5);
      var item2 = new Item(new Product("KDKDK", "Cookie"), 1, 6);

      var findPO = await mock.FindPurchaseOrderAsync(1);
      var addItem = await mock.AddItemToExistingPurchaseOrderAsync(findPO,new List<Item>{item1,item2 });

      //then the items should be added
      Assert.True(addItem);
    }
  }
}
