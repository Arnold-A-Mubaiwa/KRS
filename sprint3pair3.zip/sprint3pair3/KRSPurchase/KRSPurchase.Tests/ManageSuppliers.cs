﻿using KRSPurchase.ApplicationServices;
using KRSPurchase.Domain;
using KRSPurchase.Tests.Mocks;

namespace KRSPurchase.Tests
{
  public class ManageSuppliers
  {
    private readonly SupplierApplicationServices _service = new (new MockSupplierRepository());
    private readonly SupplierValidator _validator = new ();

    [Fact]
    public void ShouldCreateSupplier()
    {
      // Given a supplier with code="HYJUK", name="Humbler", leadTime=2 (days)
      var code = "HYJUK";
      var name = "Humbler";
      var leadTime = 2;
      
      // When we create a new Supplier
      var supplier = new Supplier(code, name, leadTime);
      
      // The supplier should exist
      Assert.NotNull(supplier);
      Assert.Equal(code, supplier.Code);
      Assert.Equal(name, supplier.Name);
      Assert.Equal(leadTime, supplier.LeadTime);
    }

    [Fact] 
    public void ShouldValidateAValidSupplier() 
    {
      // Given a supplier with code="BYPAS", name="Bipolors", leadtime=2
      var supplier = new Supplier("BYPAS", "Bipolors", 2);
      
      // When the supplier is validated
      var validate = _validator.Validate(supplier);
      
      // Then the supplier is Valid
      Assert.True(validate.IsValid);
    }

    [Fact]
    public void ShouldValidateAnInValidSupplier()
    {
      // Given a supplier with code="PERME", name="Permanent", leadtime=-1
      var supplier = new Supplier("PERME", "Permanent", -1);
      
      // When the supplier is validated
      var validated = _validator.Validate(supplier);
      
      // Then the supplier is Valid
      Assert.False(validated.IsValid);
    }

    [Fact]
    public async Task ShouldFindbyCode()
    {
      // Given a supplier with code "GTYAR"
      var code = "GTYAR";
      
      // When finding a already existing supplier in the AppService
      var (isSuccess, isFailed, supplier, errors) = await _service.FindSupplierAsync(code);
      
      // Then the supplier should exist
      Assert.NotNull(supplier);
      Assert.True(isSuccess);
      Assert.False(isFailed);
      Assert.Null(errors);
      Assert.Equal(code, supplier.Code);
    }

    [Fact]
    public async Task ShouldFindSupplierbyId()
    {
      // Given a supplier with code "GTYAR"
      var id = 1;

      // When finding a already existing supplier in the AppService
      var (isSuccess, isFailed, supplier, errors) = await _service.FindSupplierByIdAsync(id);

      // Then the supplier should exist
      Assert.NotNull(supplier);
      Assert.True(isSuccess);
      Assert.False(isFailed);
      Assert.Null(errors);
      Assert.Equal(id, supplier.supplierid);
    }

    [Fact]
    public async Task ShouldAddSupplierAsync()
    {
      // Given a supplier with code="REDDR", name="Redragon", leadtime=5
      var supplier = new Supplier("REDDS", "Redragon", 3);

      // When a supplier added to the application service
      var (isSuccess, isFailed, addedSupplier, errors) = await _service.AddSupplierAsync(supplier);
      var isSupplierAdded = (await _service.FindSupplierByIdAsync(addedSupplier)).Value;
      
      // Then the supplier should exist on the App Servcic
      Assert.True(isSuccess);
      Assert.False(isFailed);
      Assert.NotNull(isSupplierAdded);
      Assert.Null(errors);
      Assert.Equal(supplier.supplierid, isSupplierAdded.supplierid);
      
    }

    [Fact]
    public async Task ShouldEditSupplierAsync()
    {
      // Given an existing supplier with code="AGILE", name="Scrum", leadTime=5
      var supplier = new Supplier("AGILE", "Scrum", 5);
      var existingSupplier = (await _service.FindSupplierAsync(supplier.Code)).Value;

      existingSupplier.Name = supplier.Name;
      existingSupplier.LeadTime = supplier.LeadTime;

      // When supplier is edited on the application service
      var isSupplierEdited = await _service.EditSupplierAsync(existingSupplier);
      

      // Then the edited supplier should exist with new name and leadtime
      var (isSuccess, isFailed, supplierEdited, errors)  = await _service.FindSupplierAsync(supplier.Code);
      Assert.True(isSuccess);
      Assert.False(isFailed);
      Assert.NotNull(isSupplierEdited);
      Assert.Null(errors);
      Assert.Equal(supplier.Name, supplierEdited.Name);
      Assert.Equal(supplier.LeadTime, supplierEdited.LeadTime); 
    }

    [Fact]
    public async Task ShouldFailToEditSupplierByCode()
    {
      // Given an existing supplier with code="RYZE", name="Ryze Energy", leadTime=5
      var supplier = new Supplier("RYZE", "Ryze Energy", 0);

      // When supplier is edited on the application service
      var isSupplierEdited = await _service.EditSupplierAsync(supplier);

      // Then the edited supplier should exist with new name and leadtime
      var (isSuccess, isFailed, supplierEdited, errors) = await _service.FindSupplierAsync(supplier.Code);
      Assert.True(isSuccess);
      Assert.False(isFailed);
      Assert.False(isSupplierEdited.IsSuccess);
      Assert.Null(supplierEdited);
      Assert.Null(errors);
    }

    [Fact]
    public async Task ShouldFailToEditSupplier()
    {
      // Given a supplier with code="RYZEE", name="Ryze Energy", leadTime=5
      var supplier = new Supplier("RYZEE", "Ryze Energy", 5);

      // When supplier is edited on the application service
      var isSupplierEdited = await _service.EditSupplierAsync(supplier);

      // Then the edited supplier should exist with new name and leadtime
      var (isSuccess, isFailed, supplierEdited, errors) = await _service.FindSupplierAsync(supplier.Code);
      Assert.True(isSuccess);
      Assert.False(isFailed);
      Assert.False(isSupplierEdited.IsSuccess);
      Assert.Null(errors);
      Assert.Null(supplierEdited);
    }

    [Fact]
    public async Task ShouldEditSupplierNameAsync()
    {
      // Given an existing supplier with code="AGILE", new name="Scrum"
      var code = "AGILE";
      var name = "Scrum";
      var supplier = (await _service.FindSupplierAsync(code)).Value;
      supplier.Name = name;

      // When supplier is edited on the application service
      var isSupplierEdited = await _service.EditSupplierAsync(supplier);

      // Then the edited supplier should exist with new name and leadtime
      var (isSuccess, isFailed, editedSupplier, errors) = await _service.FindSupplierAsync(supplier.Code);
      Assert.True(isSuccess);
      Assert.False(isFailed);
      Assert.NotNull(isSupplierEdited);
      Assert.Null(errors);
      Assert.Equal(supplier.Name, editedSupplier.Name);
    }

    [Fact]
    public async Task ShouldEditSupplierLeadTimeAsync()
    {
      // Given an existing supplier with code="AGILE", new leadTime=6
      var code = "AGILE";
      var leadTime = 6;
      var supplier = (await _service.FindSupplierAsync(code)).Value;
      supplier.LeadTime = leadTime;

      // When supplier is edited on the application service
      var isSupplierEdited = await _service.EditSupplierAsync(supplier);

      // Then the edited supplier should exist with new name and leadtime
      var (isSuccess, isFailed, editedSupplier, errors) = await _service.FindSupplierAsync(supplier.Code);
      Assert.True(isSuccess);
      Assert.False(isFailed);
      Assert.NotNull(isSupplierEdited);
      Assert.Null(errors);
      Assert.Equal(supplier.LeadTime, editedSupplier.LeadTime);
    }

    [Fact]
    public async Task ShouldDeleteAnExistingSupplierAsync()
    {
      // Given an existing suppier with code="GIELS"
      var id = 2;
      var existingSupplier = (await _service.FindSupplierByIdAsync(id)).Value;

      // When supplier is deleted on the application service
      var (isSuccess, isFailed, deleteSupplier, errors) = await _service.DeleteSupplierAsync(existingSupplier.supplierid);
      
      // Then the supplier should not exist
      var deletedSupplier = (await _service.FindSupplierByIdAsync(id)).Value;
      Assert.True(isSuccess);
      Assert.False(isFailed);
      Assert.True(deleteSupplier);
      Assert.Null(errors);
      Assert.Null(deletedSupplier);
    }

    [Fact]
    public async Task ShouldListSuppliersAsync()
    {
      // Given a AS with at least 1 supplier
      var code = "REDDR";
      // When we fetch the list from AS
      var listOfSuppliers = await _service.ListSuppliersAsync();
      //var supple = await _service.FindSupplierAsync(code);
      // Then the list should have at least 1 supplier
      Assert.Contains(listOfSuppliers.Value, s => s.Code == code);
      Assert.True(listOfSuppliers.IsSuccess);
      Assert.True(listOfSuppliers.Value.Count > 1);
    }

    [Fact]
    public async Task ShouldCheckDuplicates()
    {
      // Give a supplier
      var supplier = new Supplier("GTYAR", "Yaris", 2) {supplierid =1};

      // When checking for duplicates 
      var checkDuplicate = await _service.CheckDuplicateAsync(supplier.supplierid);

      // Then the supplier should exists
      Assert.True(checkDuplicate);
    }

    [Fact]
    public async Task ShouldFailToAddSupplier()
    {
      // Given an already existing supplier with code="REDDR", name="Redragon", leadtime=5
      var supplier = new Supplier("REDDR", "Redragon", 5) {supplierid=2};

      // When a supplier is added to the application service
      var (isSuccess, isFalied, addSupplier, errors) = await _service.AddSupplierAsync(supplier);

      // Then the supplier shouldn't be added to the Application Service if it's duplicate
      Assert.False(isSuccess);
      Assert.True(isFalied);
      Assert.NotEmpty(errors);
      Assert.Equal(0, addSupplier);
    }

    [Fact]
    public async Task ShouldFailToAddSupplierById()
    {
      // Given an already existing supplier with code="YNGLAA", name="Young LA", leadtime=5
      var supplier = new Supplier("YNGLAA", "Young LA", 5);

      // When a supplier is added to the application service
      var (isSuccess, isFalied, addSupplier, errors) = await _service.AddSupplierAsync(supplier);

      // Then the supplier shouldn't be added to the Application Service if it's duplicate
      Assert.False(isSuccess);
      Assert.True(isFalied);
      Assert.NotEmpty(errors);
      Assert.Equal(0, addSupplier);
    }

    [Fact]
    public async Task ShouldFailToDeleteSupplier()
    {
      // Given an existing product with code = "WHERE"
      var id = 47;

      // When deleting the product
      var(isSuccess, isFailed, delete, errors) = await _service.DeleteSupplierAsync(id);

      // Then the product should be deleted
      Assert.False(delete);
      Assert.True(isFailed);
      Assert.False(isSuccess);
      Assert.NotNull(errors);
    }

    [Fact]
    public async Task ShouldFailToDeleteSupplierByCodeMock()
    {
      // Given a non existing supplier with code = "WHERE"
      var id = 47;

      // When deleting the supplier
      var mock = new MockSupplierRepository();
      var deleteSupplier = await mock.DeleteSupplierAsync(id);

      // Then the product should not be deleted
      var findDeletedSupplier = await mock.FindSupplierByIdAsync(id);
      Assert.False(deleteSupplier);
      Assert.Null(findDeletedSupplier);
    }
  }
}
