﻿using FluentResults;
using KRSPurchase.Domain;
using KRSPurchase.Infrastructure;

namespace KRSPurchase.Tests.Mocks
{
  public class MockPurchaseOrdersRepository : IPurchaseOrdersRepository
  {
    private List<PurchaseOrder> _purchaseOrders = new List<PurchaseOrder>()
    {
      new PurchaseOrder ( new Supplier("ABCDA", "Ab", 3), new List<Item>() { new Item(new Product("WEARV", "Wearing Clothe"), 2, 50.52m) }),
    };

    private List<SupplierPurchaseOrderDTO> _pODtos = new List<SupplierPurchaseOrderDTO>()
    {
      new SupplierPurchaseOrderDTO(1, DateTime.Now, 2, "SAMSUNG", "SMSNG", 2, 1, DateTime.Now, "Arnold", "Arnold", DateTime.Now, new List<Item>() { new Item(new Product("WEARV", "Wearing Clothe"), 2, 50.52m) })
    };


    public async Task<SupplierPurchaseOrderDTO> FindPurchaseOrderAsync(int number)
    {
      return _pODtos.FirstOrDefault(p => p.Number == number)!;
    }

    public async Task<bool> AddPurchaseOrderAsync(PurchaseOrder purchase)
    {
      purchase.Number = _purchaseOrders.Count + 1;
      _purchaseOrders.Add(purchase);
      var items = purchase.Items;
      var SPdtoAdd = new SupplierPurchaseOrderDTO(purchase.Number, purchase.OrderDate, purchase.Supplier.SupplierId, purchase.Supplier.Name, purchase.Supplier.Code, purchase.Supplier.LeadTime, 1, DateTime.Now, "Tino", "Tino", DateTime.Now, items.ToList());
      _pODtos.Add(SPdtoAdd);
      return true;
    }

    public async Task<bool> AddItemToExistingPurchaseOrderAsync(SupplierPurchaseOrderDTO purchase, List<Item> items)
    {
      items.ForEach(purchase.Add);
      return true;
    }
    
    public async Task<bool> AddItemsToPurchaseOrder(int number, Item item)
    {
      var findPO = await FindPurchaseOrderAsync(number);
      if (findPO != null)
      {
        findPO.Add(item);
        return true;
      }
      return false;
    }

    public async Task<bool> CancelOrderAsync(int number)
    {
      var existingPurchaseOrder = await FindPurchaseOrderAsync(number);

      if (existingPurchaseOrder == null) 
        return existingPurchaseOrder != null;

      existingPurchaseOrder.Active = 0;
      return existingPurchaseOrder == null;
    }

    public async Task<List<PurchaseOrder>> ListPurchaseOrdersAsync()
    {
      return _purchaseOrders;
    }
    public async Task<List<SupplierPurchaseOrderDTO>> ListPurchaseOrderAsync()
    {
      return _pODtos;
    }

    public Task<bool> AddItemToExistingPurchaseOrderAsync(PurchaseOrder purchase, List<Item> items)
    {
      throw new NotImplementedException();
    }

    public async Task<List<ItemDto>> ListItems(int id) 
    { 
      throw new NotImplementedException(); 
    }
    public Task<PurchaseOrder> FindPurchaseOrderByNumber(int number)
    {
      throw new NotImplementedException();
    }
  }
}
