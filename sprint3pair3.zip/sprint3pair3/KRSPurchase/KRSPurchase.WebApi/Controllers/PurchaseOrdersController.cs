﻿using KRSPurchase.ApplicationServices;
using KRSPurchase.Domain;
using KRSPurchase.WebApi.Extensions;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace KRSPurchase.WebApi.Controllers
{
  [Route("api/[controller]")]
  [ApiController]
  public class PurchaseOrdersController : ControllerBase
  {
    private readonly PurchaseOrderApplicationService _purchaseApplicationService;
    public PurchaseOrdersController(PurchaseOrderApplicationService purchaseApplicationService)
    {
      _purchaseApplicationService = purchaseApplicationService;
    }

    // GET: api/PurchaseOrders
    [HttpGet]
    public async Task<IActionResult> Get()
      => (await _purchaseApplicationService.ListPurchaseOrderAsync()).ToActionResult(Request.HttpContext);

    // GET api/PurchaseOrders/5
    [HttpGet("{number}", Name = "Get Number")]
    public async Task<IActionResult> Get(int number)
      => (await _purchaseApplicationService.FindPurchaseOrderAsync(number)).ToActionResult(Request.HttpContext);

    // POST api/PurchaseOrders
    [HttpPost]
    public async Task<IActionResult> Post([FromBody] PurchaseOrderAddDto purchaseOrder)
      => (await _purchaseApplicationService.AddPurchaseOrderAsync(new PurchaseOrder(purchaseOrder))).ToActionResult(Request.HttpContext);

    // PUT api/PurchaseOrders/5/item
    [HttpPut("{number}/item")]
    public async Task<IActionResult> Put(int number, Item item)
      => (await _purchaseApplicationService.AddItemToExistingPurchaseOrderAsync(number, item)).ToActionResult(Request.HttpContext);

    // PUT api/PurchaseOrders/5/cancel
    [HttpPut("{number}/cancel")]
    public async Task<IActionResult> Put(int number)
     => (await _purchaseApplicationService.CancelPurchaseOrderAsync(number)).ToActionResult(Request.HttpContext);
  }
}
