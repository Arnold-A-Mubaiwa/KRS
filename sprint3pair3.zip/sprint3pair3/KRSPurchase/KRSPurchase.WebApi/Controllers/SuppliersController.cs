﻿using KRSPurchase.ApplicationServices;
using KRSPurchase.Domain;
using KRSPurchase.WebApi.Extensions;
using KRSPurchase.WebApi.Filters;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace KRSPurchase.WebApi.Controllers
{
  [Route("api/[controller]")]
  [ApiController]
  public class SuppliersController : ControllerBase
  {
    private readonly SupplierApplicationServices _supplierService;
    public SuppliersController(SupplierApplicationServices supplierService)
    {
      _supplierService = supplierService;
    }

    // GET: api/Suppliers
    [HttpGet]
    public async Task<IActionResult> Get()
          => (await _supplierService.ListSuppliersAsync()).ToActionResult(Request.HttpContext);

    // GET: api/Suppliers/5
    [HttpGet("code/{code}", Name = "Get Name")]
    public async Task<IActionResult> Get(string code)
      => (await _supplierService.FindSupplierAsync(code)).ToActionResult(Request.HttpContext);

    [HttpGet("{id}", Name = "GetSupplierId")]
    public async Task<IActionResult> Get(int id)
      => (await _supplierService.FindSupplierByIdAsync(id)).ToActionResult(Request.HttpContext);
    // POST api/Suppliers

    [HttpPost]
    public async Task<IActionResult> Post([FromBody] Supplier supplier)
    {
      supplier.createuser = "Web user";
      return (await _supplierService.AddSupplierAsync(supplier)).ToActionResult(Request.HttpContext);
    }

    // PUT api/<Suppliers/5
    [HttpPut("{id}")]
    [ValidateRoute("id", "supplierid")]
    public async Task<IActionResult> Put([FromBody] Supplier supplier) 
      => (await _supplierService.EditSupplierAsync(supplier)).ToActionResult(Request.HttpContext);
    
    // DELETE api/Suppliers/5
    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
      => (await _supplierService.DeleteSupplierAsync(id)).ToActionResult(Request.HttpContext);
  }
}
