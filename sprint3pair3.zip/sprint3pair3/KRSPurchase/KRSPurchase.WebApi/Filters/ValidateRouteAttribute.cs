﻿using Microsoft.AspNetCore.Mvc.Filters;
using System;

namespace KRSPurchase.WebApi.Filters
{
  public class ValidateRouteAttribute : ActionFilterAttribute
  {
    private readonly string _routeParamName;
    private readonly string _modelPropName;

    public ValidateRouteAttribute(string routeParamName, string modelPropName)
    {
      _routeParamName = routeParamName;
      _modelPropName = modelPropName;
    }

    public override void OnActionExecuting(ActionExecutingContext context)
    {
      var routeParam = context.RouteData.Values[_routeParamName]?.ToString();
      object keyValuePair = context.ActionArguments.LastOrDefault().Value;
      var modelPropValue = keyValuePair
        .GetType()
        .GetProperty(_modelPropName)?.GetValue(keyValuePair, null).ToString();

      if (string.IsNullOrEmpty(routeParam) ||
          string.IsNullOrEmpty(modelPropValue) ||
          routeParam != modelPropValue)
        throw new Exception("Mismatch between route id and body id");

      base.OnActionExecuting(context);
    }
  }
}
