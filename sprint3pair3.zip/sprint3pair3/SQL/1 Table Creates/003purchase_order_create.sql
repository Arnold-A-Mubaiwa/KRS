use krspurchase
go

if not exists 
(
select 1 from sys.objects
where name='purchaseOrder'
and type ='U'
)
begin
  create table purchaseOrder
  (
  purchaseorderno int                        identity primary key,
  supplierid      int                        foreign key references supplier(supplierid),
  orderdate       datetime          not null,
  cancel          bit               not null default 0,
  createuser      nvarchar(500),
  createdate      datetime2,
  edituser        nvarchar(500),
  editdate        datetime2
  )
end
go
