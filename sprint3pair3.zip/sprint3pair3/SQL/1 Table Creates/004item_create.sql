use krspurchase
go

if not exists (
select 1 from sys.objects 
where Type = 'U' and name = 'item'
)
begin
create table item(
  itemid          int identity(1,1) primary key,
  purchaseorderno int foreign key   references purchaseOrder(purchaseorderno),
  productid       int foreign key   references product(productid),
  quantity        decimal(12,3),
  price           money,
  createuser      nvarchar(500),
  createdate      datetime2,
  edituser        nvarchar(500),
  editdate        datetime2
  )
  end
  go