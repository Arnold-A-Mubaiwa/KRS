use krspurchase
go

  if not exists ( select 1 
                  from sys.objects 
                  where name = 'products' and type = 'U')
begin
   create table product(
        productid   int           identity(1,1) primary key,
        code        nchar(5)      not null      unique,
        name        nvarchar(500) not null,
        createuser  nvarchar(500) not null,
        createdate  datetime2     not null,
        edituser    nvarchar(500) not null,
        editdate    datetime2     not null,
  )
end
