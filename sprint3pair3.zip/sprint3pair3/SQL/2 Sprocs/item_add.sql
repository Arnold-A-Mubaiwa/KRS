use krspurchase
go

drop proc if exists item_add
go

create proc item_add
(
  @productid int,
  @purchaseorderno int,
  @quantity int,
  @price money,
  @user nvarchar(500)
)
as
declare @date datetime2 = getdate()
insert into item
(
  productid,
  purchaseorderno,
  quantity,
  price,
  createuser,
  createdate,
  edituser,
  editdate
)
values(
  @productid,
  @purchaseorderno,
  @quantity,
  @price,
  @user,
  @date,
  @user,
  @date
)
go

grant execute on item_add to public
go
