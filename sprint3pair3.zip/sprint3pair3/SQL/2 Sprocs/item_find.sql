use krspurchase
go

drop proc if exists item_find

go

create proc item_find
(
@id int
)
as
  select 
    i.purchaseorderno as 'number',
    i.productid,
    i.quantity,
    i.price,
    i.createuser,
    i.createdate,
    i.edituser ,
    i.editdate,
     p.code,
    p.name,
    p.createuser as 'productcreateuser',
    p.createdate as 'productcreatedate',
    p.editdate   as 'producteditdate',
    P.edituser   as 'productedituser',
    p.productid,
    p.code
  from item i
  join product p on p.productid = i.productid
  where purchaseorderno = @id
go

grant execute on purchaseorder_listAll to public
go
