use krspurchase
go

drop proc if exists products_delete
go

create proc products_delete
(
 @id int
)
  as 
    delete 
    from   products
    where  productid = @id
go

grant execute on products_delete to public
go