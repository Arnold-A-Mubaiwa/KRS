use krspurchase
go

drop proc if exists products_edit
go

create proc products_edit
(
  @id int,
  @name nvarchar(500),
  @edituser nvarchar(500)
)
as
  update product
  set name = @name, edituser = @edituser, editdate = getdate()
  where productid = @id
go

grant execute on products_edit to public
go