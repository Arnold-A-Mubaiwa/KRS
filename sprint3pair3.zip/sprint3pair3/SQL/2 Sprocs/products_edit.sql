use krspurchase
go

drop proc if exists product_edit
go

create proc product_edit
(
  @id int,
  @name nvarchar(500),
  @edituser nvarchar(500)
)
as
  update product
  set name = @name, edituser = @edituser, editdate = getdate()
  where productid = @id
go

grant execute on product_edit to public
go