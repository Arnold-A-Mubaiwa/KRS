use krspurchase
go

drop proc if exists product_findByCode
go

create proc product_findByCode
(
@code nchar(5)
)
as
  select
    productid,
    code,
    name,
    createuser,
    createdate,
    edituser,
    editdate
  from product
  where code = @code
go

grant execute on product_findByCode to public
go