use krspurchase
go

drop proc if exists products_findbyid 
go 

create proc products_findbyid
(
   @id int
)
as
  select productid,
         code,
         name,
         createuser,
         createdate,
         edituser,
         editdate
  from product

  where productid = @id
  go

  grant execute on products_findbyid to public
  go