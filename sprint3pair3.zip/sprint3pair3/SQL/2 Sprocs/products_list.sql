use krspurchase
go

drop proc if exists product_list 
go
  
create proc product_list
as
  select productid,
          code,
          name,
          createuser,
          createdate,
          edituser,
          editdate
  from   product
 go

 grant execute on product_list to public
 go
