use krspurchase
go

drop proc if exists products_list 
go
  
create proc products_list
as
  select productid,
          code,
          name,
          createuser,
          createdate,
          edituser,
          editdate
  from   product
 go

 grant execute on products_list to public
 go
