use krspurchase
go

drop proc if exists purchaseorder_add
go

create proc purchaseorder_add
(
  @supplierid int,
  @user nvarchar(500)
)
as
  declare @nowdate datetime2 = getdate()
  insert into purchaseOrder
  (
    supplierid,
    orderdate, 
    createuser,
    createdate, 
    edituser, 
    editdate
  )
  values 
  (
    @supplierid, 
    @nowdate, 
    @user,
    @nowdate, 
    @user, 
    @nowdate
  )
  select @@IDENTITY
go

grant execute on purchaseorder_add to public
go
