use krspurchase
go

drop proc if exists purchaseorder_cancel
go

create proc purchaseorder_cancel
(
@id int
)
as
  update purchaseOrder
  set cancel = 1
  where purchaseorderno = @id
go

grant execute on purchaseorder_cancel to public
go