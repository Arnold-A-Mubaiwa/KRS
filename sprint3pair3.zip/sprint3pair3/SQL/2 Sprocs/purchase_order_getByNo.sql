use krspurchase
go

select * from purchaseOrder
drop proc if exists purchaseorder_getByNo
go

create proc purchaseorder_getByNo
(
@id int
)
as
  select
    p.purchaseorderno,
    p.supplierid,
    p.orderdate,
    p.cancel,
    s.leadtime,
    p.createuser,
    p.createdate,
    p.edituser,
    p.editdate
  from purchaseOrder p
  join supplier s on s.supplierid = p.supplierid
  where purchaseorderno = @id
go

grant execute on purchaseorder_getByNo to public
go
