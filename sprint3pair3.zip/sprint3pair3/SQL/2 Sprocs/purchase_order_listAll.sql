use krspurchase
go

drop proc if exists purchaseorder_listAll
go

create proc purchaseorder_listAll
as
  select 
    p.purchaseorderno,
    p.supplierid,
    p.orderdate,
    p.cancel,
    p.createuser,
    p.createdate,
    p.edituser,
    p.editdate
  from purchaseOrder p
  join supplier s on s.supplierid = p.supplierid
go

grant execute on purchaseorder_listAll to public
go
