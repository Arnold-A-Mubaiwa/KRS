use krspurchase
go

drop proc if exists supplier_add
go

create proc supplier_add
(
@code     nchar(5),
@name     nvarchar(500),
@leadtime int,
@user     nvarchar(500)
)
as
  declare @nowtime datetime2 = getdate()
  insert into supplier
  (
    code, 
    name, 
    leadtime, 
    createuser, 
    createdate, 
    edituser, 
    editdate
   )
   values
   (
    @code,
    @name,
    @leadtime,
    @user,
    @nowtime,
    @user,
    @nowtime
   )
   select @@IDENTITY
go

grant execute on supplier_add to public
go

