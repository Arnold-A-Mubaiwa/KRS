use krspurchase
go

drop proc if exists suppliers_delete
go

create proc suppliers_delete
(
  @id int
)
as
  delete
  from  supplier
  where supplierid = @id
go

grant execute on suppliers_delete to public
go