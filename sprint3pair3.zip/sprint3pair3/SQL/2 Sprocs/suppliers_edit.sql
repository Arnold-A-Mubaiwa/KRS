use krspurchase
go

drop proc if exists suppliers_edit
go

create proc suppliers_edit
(
  @id         int,
  @name       nvarchar(500),
  @leadtime   int,
  @editname   nvarchar(500)
)
as
  update supplier
  set
    name           = @name,
    leadtime       = @leadtime,
    edituser       = @editname,
    editdate       = getdate()
  where supplierid = @id
go

grant execute on suppliers_edit to public
go