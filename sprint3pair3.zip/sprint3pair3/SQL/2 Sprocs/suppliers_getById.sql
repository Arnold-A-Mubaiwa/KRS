use krspurchase
go

drop proc if exists suppliers_getById
go

create proc suppliers_getById
(
  @id int
)
as
  select
    supplierid,
    code,
    name,
    leadtime,
    createuser,
    createdate,
    edituser,
    editdate
  from supplier
  where supplierid = @id
go

grant execute on suppliers_getById to public
go