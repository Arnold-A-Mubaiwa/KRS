use krspurchase
go

drop proc if exists suppliers_list
go

create proc suppliers_list
as
  select
    supplierid,
    code,
    name,
    leadtime,
    createuser,
    createdate,
    edituser,
    editdate
  from supplier
go

grant execute on suppliers_list to public
go