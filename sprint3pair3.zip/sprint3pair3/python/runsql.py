import os
import sys
import pyodbc

def print_green(text):
    print("\033[92m {}\033[00m" .format(text))

def print_red(text):
    print("\033[91m {}\033[00m" .format(text))    

def print_yellow(text):
    print("\033[93m {}\033[00m" .format(text))


def process_sql_file(sql):
    statements = sql.split('go\n')
    # pyodbc doesn't like the 'go' keyword
    statements = [s.strip().rstrip('go') for s in statements if s.strip()]
    valid_statement_starters = ('drop', 'create', 'grant', 'if', 'alter') # valid use cases on the internship -> might need to change
    valid_statements = [s for s in statements if s.lower().startswith(valid_statement_starters)] 
    return valid_statements


def create_connection(server, database, user, password):
    connection_string = f'DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};UID={user};PWD={password}'
    connection = pyodbc.connect(connection_string)
    return connection


def get_file(path):
    try:
        with open(path, 'r') as f:
            sql = f.read()
            return sql
    except Exception as e:
        print_red("Error loading files", e)
        sys.exit(1)


def run_sql_file(connection, sql_file, fpath):
    try:
        cursor = connection.cursor()
        sql_commands = process_sql_file(sql_file)
        for command in sql_commands:
            if command.strip():
                cursor.execute(command)
        cursor.commit()
    except Exception as e:
        print_red("Error while connecting to SQL", e)
        sys.exit(1)


try:
    current_dir = os.path.dirname(os.path.realpath(__file__))
    print_green(f"Starting script {current_dir}")    
    [server, database, user, password, root_dir] = sys.argv[1:]
except ValueError:
    print_red('Please provide server, database, user, and password arguments')
    sys.exit(1)

try:
    connection = create_connection(server, database, user, password)
    print_green(f"Connected to {server} {database}")
    print_yellow(f"Attempting to run scripts from {root_dir}...")
    for dirpath, dirnames, filenames in os.walk(root_dir):
        # Sort the directory names alphabetically
        dirnames.sort()
        print_green(f"Processing directory {dirpath}")
        for filename in sorted(filenames): # Sort the file names alphabetically
            print_green(f"Processing file {filename}")
            if filename.endswith('.sql'):
                fpath = os.path.join(dirpath, filename)
                sql = get_file(fpath)
                print_green(f"Running script {fpath}")
                run_sql_file(connection, sql, fpath)
                print_green(f"Finished script {fpath}")
    connection.close()
    print_green("Script finished successfully!")
except Exception as e:
    print_red("Failed to run script", e)
    sys.exit(1)