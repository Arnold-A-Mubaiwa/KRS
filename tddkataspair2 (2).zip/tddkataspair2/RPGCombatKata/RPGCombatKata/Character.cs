﻿namespace RPGCombatTest
{
  public class Character
  {
    /*  private int health = 1000;*/
    public int Health { get; set; }
    public int Level { get; set; }
    public bool Alive { get { return Health > 0; } }
    public bool Faction { get; set; }
    public int MaxHealth { get; set; }

    public void DealDamage(int damage, Character attacker)
    {
      if (this == attacker)
      {
        return;
      }
      if (this.Level - attacker.Level >= 5)
        damage -= (damage / 2);
      else if (attacker.Level - this.Level >= 5)
        damage += (damage / 2);

      this.Health -= damage;
      this.Health = (this.Health < 0) ? 0 : this.Health;
    }

    public void GiveHealth(int healthGiven, Character healer)
    {
      if (this == healer)
      {
        healthGiven = (this.Health + healthGiven > 1000) ? 1000 - this.Health : healthGiven;
        this.Health = (this.Health >= 1000 || this.Health <= 0) ? Health : Health + healthGiven;
      }
    }

    public bool CheckLevel(Character character)
    {
      if (character.Level < 6)
      {
        MaxHealth = 1000;
        return false;
      }
      else
      {
        MaxHealth = 1500;
        return true;
      }

    }
  }
}