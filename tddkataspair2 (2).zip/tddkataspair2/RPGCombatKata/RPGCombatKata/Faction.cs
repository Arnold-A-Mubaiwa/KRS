﻿namespace RPGCombatTest
{
  internal class Faction
  {
    //IEnumerable<object> factions = List<Character>{}
    List<Character> factions = new List<Character>();
  }
}