﻿namespace RPGCombatTest
{
  internal class MagicalObject
  {
    public int Health { get; set; }

    //public void 
  }
}