using System.Reflection.PortableExecutable;
using System.Xml.Serialization;
using Xunit;

namespace RPGCombatTest
{
  public class UnitTest1
  {
    [Fact]
    public void CheckHealthIs1000AtStart()
    {
      var character = new Character();
      character.Health = 1000;
      int health = character.Health;
      Assert.Equal(1000, health);
    }

    [Fact]
    public void LevelStartWith1()
    {
      var character = new Character();
      character.Level = 1;
      int level = character.Level;
      Assert.Equal(1, level);
    }

    [Fact]
    public void DeadOrAlive()
    {
      var character = new Character();
      character.Health+= 1000;
      bool alive = character.Alive;
      Assert.True(alive);
    }

    [Fact]
    public void isCharacterInFactionOrNot()
    {
      var character = new Character();
      character.Faction = false;
      bool faction = character.Faction;
      Assert.False(faction);
    }

    [Fact]
    public void CharacterDealDamage()
    {
      var character = new Character();
      character.Health = 1000;
      var character2 = new Character();
      character.DealDamage(100, character2);
      int dealDamage = character.Health;
      Assert.Equal(900, dealDamage);
    }

    [Fact]
    public void CheackIfCharacterIsDeadOrAlive()
    {
      var character = new Character();
      character.Health = 1000;
      var character2 = new Character();
      character.DealDamage(1001, character2);
      Assert.False(character.Alive);
    }

    [Fact]
    public void HealCcharacter()
    {
      var character = new Character();
      character.Health = 1000;
      character.GiveHealth(1000, character);
      Assert.Equal(1000, character.Health);
    }

    [Fact]
    public void ShouldNotIncreaseHealthMoreThan1000()
    {
      var character = new Character();
      character.Health = 1000;
      character.DealDamage(500, character);
      character.GiveHealth(1000, character);
      Assert.Equal(1000, character.Health);
    }

    [Fact]
    public void CheckAttackerIsADifferentCharacter()
    {
      var character = new Character();
      character.Health = 1000;
      var character2 = new Character();
      character.DealDamage(100, character2);
      int dealDamage = character.Health;
      Assert.Equal(900, dealDamage);
    }

    [Fact]
    public void CheckThatCharacterCanHealItself()
    {
      var character = new Character();
      character.Health = 1000;
      character.GiveHealth(1000, character);
      Assert.Equal(1000, character.Health);
    }

    [Fact]
    public void CheckingIfAttackerIs5LevelsBelowTheAtackee()
    {
      var character = new Character();
      var character2 = new Character();
      character.Health = 100;
      character.Level = 8;
      character2.Level = 3;
      character.DealDamage(10, character2);
      Assert.Equal(95, character.Health);
    }

    [Fact]
    public void CheckingIfAttackerIs5LevelsAboveTheAtackee()
    {
      var character = new Character();
      var character2 = new Character();
      character.Health = 100;
      character.Level = 3;
      character2.Level = 8;
      character.DealDamage(10, character2);
      Assert.Equal(85, character.Health);
    }

    [Fact]
    public void ShouldIncreaseMaximumHealthTo1500WhenCharacterReachesLevel6()
    {
      var character = new Character();
      Assert.False(character.CheckLevel(character));
    }

    /*[Fact]
    public void CheckThatCharacterBelongsToAFaction()
    {
      var character = new Character();
      var faction = new Faction();
      faction.factions.Add(character);
      bool charInFac = faction.factions.Contains(character);
      Assert.True(charInFac);
    }*/

    [Fact]
    public void CheckMagicalObjectHealth()
    {
      var magicalObject = new MagicalObject();
      magicalObject.Health = 1000;
      int health = magicalObject.Health;
      Assert.Equal(1000, health);
    }
  }
}

