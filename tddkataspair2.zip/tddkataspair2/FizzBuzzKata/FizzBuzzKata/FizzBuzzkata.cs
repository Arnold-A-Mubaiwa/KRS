﻿using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Linq;

namespace FizzBuzzKata
{
  internal class FizzBuzzkata
  {
    public static string CheckValue(int number)
    {
      if (number % 3 == 0 && number % 5 == 0)
        return "FizzBuzz";
      else if (number.ToString().Contains("3") && number.ToString().Contains("5"))
      {
        if (number % 5 == 0)
          return "FizzBuzzBuzz";
        return "FizzBuzz";
      }
      else if (number % 3 == 0 || number.ToString().Contains("3"))
        return "Fizz";
      else if (number % 5 == 0 || number.ToString().Contains("5"))
        return "Buzz";
      return number.ToString();
    }

    internal static string Run(int testingNumbers)
    {
      /*string FizzBuzzString = string.Empty;
      for (int i = 1; i <= testingNumbers; i++)
      {
        FizzBuzzString += (CheckValue(i) + "\r\n");
      }

      return FizzBuzzString.Remove(FizzBuzzString.Length - 2);*/

      IEnumerable<int> fizzBuzzSequence = Enumerable.Range(1, 100); // [1,2,3,4..100]
      var r = fizzBuzzSequence.Select(r => CheckValue(r)); //[1,2,fizz,4,buzz...
      return string.Join(Environment.NewLine, r);

    }
  }
}