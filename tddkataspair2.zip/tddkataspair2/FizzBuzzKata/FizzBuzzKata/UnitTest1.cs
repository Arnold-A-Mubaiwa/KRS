namespace FizzBuzzKata
{
  public partial class UnitTest1
  {
    [Fact]
    public void ShouldReturnAStringOfFizzBuzzOrNumber()
    {
      var v = FizzBuzzkata.Run(100);
      Assert.Equal(_fizzBuzzExpectedResultUpTo100, v);
    }
  }
}
